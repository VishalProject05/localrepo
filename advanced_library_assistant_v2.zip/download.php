<?php
require_once "auth.php";
requireLogin();
$id = (int)($_GET["id"] ?? 0);
$stmt = $pdo->prepare("SELECT title,digital_file FROM books WHERE id=?");
$stmt->execute([$id]);
$book = $stmt->fetch();
if (!$book || empty($book["digital_file"])) {
    http_response_code(404);
    exit("PDF is not available because the library has not received an authorized digital copy.");
}
$filename = basename($book["digital_file"]);
$path = __DIR__ . "/digital_books/" . $filename;
if (!is_file($path)) {
    http_response_code(404);
    exit("PDF is not available because its file is missing from the digital_books folder.");
}
header("Content-Type: application/pdf");
header("Content-Disposition: attachment; filename=\"" . preg_replace('/[^A-Za-z0-9._-]/', "_", $book["title"]) . ".pdf\"");
header("Content-Length: " . filesize($path));
readfile($path);
exit;
