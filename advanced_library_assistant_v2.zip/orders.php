<?php
require_once "auth.php"; requireLogin();
$pageTitle='My Orders';
if($_SESSION['role']==='Admin'){$st=$pdo->query("SELECT o.*,u.full_name FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC");}else{$st=$pdo->prepare("SELECT o.*,u.full_name FROM orders o JOIN users u ON u.id=o.user_id WHERE o.user_id=? ORDER BY o.id DESC");$st->execute([$_SESSION['user_id']]);}
$orders=$st->fetchAll();
require 'partials/header.php';require 'partials/sidebar.php'; ?>
<div class="d-flex justify-content-between align-items-center"><h5>🧾 <?= $_SESSION['role']==='Admin'?'Orders Management':'My Orders' ?></h5><a class="btn btn-sm btn-outline-primary" href="search.php">Shop Books</a></div>
<?php if(isset($_GET['placed'])):?><div class="alert alert-success mt-3">Order #<?=e($_GET['placed'])?> placed successfully.</div><?php endif; ?>
<div class="card p-3 mt-3 table-responsive"><table class="table align-middle"><thead><tr><th>Order</th><?php if($_SESSION['role']==='Admin'):?><th>Customer</th><?php endif;?><th>Total</th><th>Payment</th><th>Status</th><th>Date</th></tr></thead><tbody><?php foreach($orders as $o):?><tr><td>#<?=$o['id']?></td><?php if($_SESSION['role']==='Admin'):?><td><?=e($o['full_name'])?></td><?php endif;?><td><?=e($o['currency'])?> <?=number_format($o['total_amount'],2)?></td><td><?=e($o['payment_method'])?></td><td><span class="badge bg-primary"><?=e($o['order_status'])?></span></td><td><?=e($o['created_at'])?></td></tr><?php endforeach;if(!$orders):?><tr><td colspan="6" class="text-muted">No orders yet.</td></tr><?php endif;?></tbody></table></div><?php require 'partials/footer.php'; ?>
