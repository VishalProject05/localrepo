INSERT INTO books (title,author,category,publisher,total_copies,available_copies,description,cover_image)
SELECT title,author,category,publisher,3,3,description,'gita-press.svg'
FROM (
SELECT 'Shrimad Bhagavad Gita' title,'Ved Vyasa' author,'Hindu Scriptures' category,'Gita Press' publisher,'Bhagavad Gita reference edition.' description UNION ALL
SELECT 'Ramcharitmanas','Goswami Tulsidas','Hindu Scriptures','Gita Press','Devotional epic and scripture edition.' UNION ALL
SELECT 'Valmiki Ramayana','Maharshi Valmiki','Hindu Scriptures','Gita Press','Classical Ramayana scripture edition.' UNION ALL
SELECT 'Shrimad Bhagavat Mahapurana','Ved Vyasa','Puranas','Gita Press','Bhagavata Purana reference edition.' UNION ALL
SELECT 'Vishnu Purana','Maharshi Parashara','Puranas','Gita Press','Traditional Vishnu Purana edition.' UNION ALL
SELECT 'Shiva Purana','Ved Vyasa','Puranas','Gita Press','Traditional Shiva Purana edition.' UNION ALL
SELECT 'Garuda Purana','Ved Vyasa','Puranas','Gita Press','Traditional Garuda Purana edition.' UNION ALL
SELECT 'Durga Saptashati','Markandeya Purana','Devotional','Gita Press','Devotional Durga scripture edition.' UNION ALL
SELECT 'Hanuman Chalisa','Goswami Tulsidas','Devotional','Gita Press','Hanuman Chalisa devotional edition.' UNION ALL
SELECT 'Narada Bhakti Sutra','Devarshi Narada','Philosophy','Gita Press','Bhakti philosophy scripture edition.' UNION ALL
SELECT 'Patanjali Yoga Darshan','Maharshi Patanjali','Yoga','Gita Press','Classical Yoga Sutra edition.' UNION ALL
SELECT 'Upanishad Collection','Various Sages','Hindu Scriptures','Gita Press','Collection of principal Upanishads.' UNION ALL
SELECT 'Manusmriti','Manu','Dharmashastra','Gita Press','Traditional Dharmashastra edition.' UNION ALL
SELECT 'Bhagavata Mahatmya','Various Sages','Devotional','Gita Press','Bhagavata devotional reading edition.' UNION ALL
SELECT 'Gopal Sahasranama','Various Sages','Devotional','Gita Press','Traditional devotional name collection.'
) AS g
WHERE NOT EXISTS (SELECT 1 FROM books b WHERE b.title=g.title AND b.publisher='Gita Press');
