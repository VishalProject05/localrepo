# Online Library Management System — Advanced Edition

## Added in this version
- Shopping cart, checkout and order history for priced local books.
- Buy button beside PDF/download when an external purchase URL exists.
- Official OSHO catalog entries with authorized purchase/eBook links.
- Multilingual Library Assistant: Auto, English, Hindi, Spanish, French, German, Bengali and Marathi.
- Chatbot book search with live database results, availability, prices, PDF and Buy buttons.
- Chatbot quick actions, typing state, language selector and safe HTML rendering.
- Profile picture shown beside the logged-in user's name in the top bar.
- Profile language preference.
- Book price, currency, language and external purchase URL fields.

## Setup
1. Copy the folder to XAMPP `htdocs`.
2. Start Apache and MySQL.
3. Import `database.sql` into phpMyAdmin for a fresh database.
4. If you already have the older project database, import `migration.sql` instead.
5. Check `config.php`; this project uses MySQL port 3307 by default.
6. Open the project in the browser and run `setup.php` once.
7. Delete `setup.php` after setup.

## Demo login
- Admin: `vishalkushwaha7451@gmail.com` / `Vishal@098`
- Student: `rahul@gmail.com` / `123456`

## OSHO content
OSHO books are copyrighted works. This project adds catalog metadata and official purchase/eBook links; it does **not** bundle unauthorized PDFs. Admins can upload PDFs in Digital PDFs only when they own or are authorized to distribute those files.

## Shopping
- Local books with a price can be added to the cart and ordered.
- External titles (such as OSHO catalog items) use the configured official purchase URL.
- The local checkout is a demo library order workflow; connect a real payment gateway before using it for actual online payments.

## Main pages
Login, Registration, Admin Dashboard, Member Dashboard, Books, Members, Issue / Return, Search & Shop, Book Details, My Books, Profile, Reports, Digital PDFs, Cart, Checkout, Orders and Library Assistant.
