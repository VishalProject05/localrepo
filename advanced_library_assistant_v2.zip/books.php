<?php
require_once "auth.php";
requireAdmin();
$pageTitle = "Books Management";
if (isset($_GET["delete"])) {
    $id = (int)$_GET["delete"];
    $s = $pdo->prepare("DELETE FROM books WHERE id=?");
    $s->execute([$id]);
    flash("success", "Book deleted.");
    header("Location:books.php");
    exit;
}
$books = $pdo->query("SELECT * FROM books ORDER BY id DESC")->fetchAll();
require "partials/header.php";
require "partials/sidebar.php"; ?>
<div class="d-flex justify-content-between align-items-center"><h5>Books Management</h5><a href="book_form.php" class="btn btn-primary btn-sm">+ Add Book</a></div>
<?php if ($m = flash("success")):?><div class="alert alert-success mt-3"><?=$m?></div><?php endif;?>
<div class="card p-3 mt-3 table-responsive"><table class="table align-middle"><thead><tr><th>#</th><th>Cover</th><th>Book Title</th><th>Author</th><th>Category</th><th>Language</th><th>Price</th><th>Total</th><th>Available</th><th>Action</th></tr></thead><tbody>
<?php foreach ($books as $i => $b):?><tr><td><?=$i + 1?></td><td><?php if (!empty($b["cover_image"])): ?><img src="assets/covers/<?=e($b["cover_image"])?>" alt="Book cover" style="width:45px;height:60px;object-fit:cover"><?php else: ?><span class="text-muted">No cover</span><?php endif; ?></td><td><a href="book_details.php?id=<?=$b["id"]?>"><?=e($b["title"])?></a></td><td><?=e($b["author"])?></td><td><?=e($b["category"])?></td><td><?=e($b["language"]??"English")?></td><td><?=e($b["currency"]??"INR")?> <?=number_format((float)($b["price"]??0),2)?></td><td><?=$b["total_copies"]?></td><td><?=$b["available_copies"]?></td><td><a class="btn btn-sm btn-outline-primary" href="book_form.php?id=<?=$b["id"]?>">✎</a> <a data-confirm="Delete this book?" class="btn btn-sm btn-outline-danger" href="?delete=<?=$b["id"]?>">🗑</a></td></tr><?php endforeach;?>
</tbody></table></div><?php require "partials/footer.php"; ?>