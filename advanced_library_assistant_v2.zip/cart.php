<?php
require_once "auth.php"; requireLogin();
$pageTitle='Shopping Cart';
$_SESSION['cart']=$_SESSION['cart']??[];
if(isset($_GET['remove'])) unset($_SESSION['cart'][(int)$_GET['remove']]);
if(isset($_POST['clear'])) $_SESSION['cart']=[];
$items=[]; $total=0;
if($_SESSION['cart']){
  $ids=array_keys($_SESSION['cart']); $in=implode(',',array_fill(0,count($ids),'?'));
  $st=$pdo->prepare("SELECT * FROM books WHERE id IN ($in)"); $st->execute($ids);
  foreach($st as $b){$qty=max(1,(int)$_SESSION['cart'][$b['id']]);$line=(float)$b['price']*$qty;$total+=$line;$b['_qty']=$qty;$b['_line']=$line;$items[]=$b;}
}
require 'partials/header.php'; require 'partials/sidebar.php'; ?>
<div class="d-flex justify-content-between align-items-center"><h5>🛒 Shopping Cart</h5><a class="btn btn-sm btn-outline-primary" href="search.php">Continue Shopping</a></div>
<div class="card p-3 mt-3">
<?php if(!$items): ?><div class="text-center p-5 text-muted">Your cart is empty.</div><?php else: ?>
<div class="table-responsive"><table class="table align-middle"><thead><tr><th>Book</th><th>Price</th><th>Qty</th><th>Total</th><th></th></tr></thead><tbody>
<?php foreach($items as $b): ?><tr><td><div class="d-flex gap-3 align-items-center"><img src="assets/covers/<?=e($b['cover_image'] ?: 'computer-science.svg')?>" style="width:50px;height:65px;object-fit:cover;border-radius:6px"><div><a href="book_details.php?id=<?=$b['id']?>"><?=e($b['title'])?></a><div class="small text-muted"><?=e($b['author'])?></div></div></div></td><td><?=e($b['currency'])?> <?=number_format((float)$b['price'],2)?></td><td><?=$b['_qty']?></td><td><b><?=e($b['currency'])?> <?=number_format($b['_line'],2)?></b></td><td><a class="btn btn-sm btn-outline-danger" href="?remove=<?=$b['id']?>">Remove</a></td></tr><?php endforeach; ?></tbody></table></div>
<div class="d-flex justify-content-between align-items-center border-top pt-3"><form method="post"><button name="clear" class="btn btn-light">Clear Cart</button></form><div class="text-end"><div class="small text-muted">Grand Total</div><h4><?=e($items[0]['currency'] ?? 'INR')?> <?=number_format($total,2)?></h4><a class="btn btn-primary" href="checkout.php">Proceed to Checkout</a></div></div>
<?php endif; ?></div><?php require 'partials/footer.php'; ?>
