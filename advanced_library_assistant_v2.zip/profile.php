 <?php

require_once "auth.php";
requireLogin();

$pageTitle = "My Profile";

$uid = $_SESSION["user_id"];

$st = $pdo->prepare("SELECT * FROM users WHERE id=?");
$st->execute([$uid]);
$u = $st->fetch();

$msg = "";
$error = "";


/* =========================
   UPDATE PROFILE
========================= */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name = trim($_POST["full_name"] ?? "");
    $mobile = trim($_POST["mobile"] ?? "");
    $password = $_POST["password"] ?? "";
    $preferredLanguage = $_POST["preferred_language"] ?? ($u["preferred_language"] ?? "auto");
    $allowedLanguages = ["auto","en","hi","es","fr","de","bn","mr"];
    if (!in_array($preferredLanguage, $allowedLanguages, true)) $preferredLanguage = "auto";

    if ($name === "") {
        $error = "Full name is required.";
    }


    /* =========================
       EXISTING PROFILE IMAGE
    ========================= */

    $profilePic = $u["profile_pic"] ?? "";


    /* =========================
       IMAGE UPLOAD
    ========================= */

    if (
        $error === "" &&
        isset($_FILES["file"]) &&
        $_FILES["file"]["error"] !== UPLOAD_ERR_NO_FILE
    ) {

        if ($_FILES["file"]["error"] !== UPLOAD_ERR_OK) {

            $error = "Image upload failed.";

        } else {

            $tmpName = $_FILES["file"]["tmp_name"];
            $fileSize = $_FILES["file"]["size"];


            /* Maximum 2MB */

            if ($fileSize > 2 * 1024 * 1024) {

                $error = "Image size must be less than 2MB.";

            } else {

                /* Check actual image type */

                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $mime = finfo_file($finfo, $tmpName);
                finfo_close($finfo);


                $allowed = [
                    "image/jpeg" => "jpg",
                    "image/png"  => "png",
                    "image/webp" => "webp"
                ];


                if (!isset($allowed[$mime])) {

                    $error = "Only JPG, PNG and WEBP images are allowed.";

                } else {

                    $extension = $allowed[$mime];


                    /* =========================
                       UPLOAD FOLDER
                    ========================= */

                    $uploadDir = __DIR__ . "/uploads/";


                    if (!is_dir($uploadDir)) {
                        mkdir($uploadDir, 0755, true);
                    }


                    /* =========================
                       FILE NAME
                    ========================= */

                    $fileName = "profile_" . $uid . "_" . time() . "." . $extension;

                    $destination = $uploadDir . $fileName;


                    /* =========================
                       MOVE IMAGE
                    ========================= */

                    if (move_uploaded_file($tmpName, $destination)) {


                        /* Delete old image */

                        if (!empty($profilePic)) {

                            $oldImage = __DIR__ . "/" . $profilePic;

                            if (file_exists($oldImage)) {
                                unlink($oldImage);
                            }
                        }


                        /* Save new image path */

                        $profilePic = "uploads/" . $fileName;

                    } else {

                        $error = "Unable to save profile picture.";

                    }
                }
            }
        }
    }


    /* =========================
       UPDATE DATABASE
    ========================= */

    if ($error === "") {

        $sql = "UPDATE users SET full_name=?, mobile=?, profile_pic=?, preferred_language=?";

        $params = [
            $name,
            $mobile,
            $profilePic,
            $preferredLanguage
        ];


        /* Change password only if entered */

        if ($password !== "") {

            $sql .= ", password=?";

            $params[] = password_hash(
                $password,
                PASSWORD_DEFAULT
            );
        }


        $sql .= " WHERE id=?";

        $params[] = $uid;


        $update = $pdo->prepare($sql);
        $update->execute($params);


        /* Update session */

        $_SESSION["full_name"] = $name;


        /* Update current user data */

        $u["full_name"] = $name;
        $u["mobile"] = $mobile;
        $u["profile_pic"] = $profilePic;
        $u["preferred_language"] = $preferredLanguage;


        $msg = "Profile updated successfully.";
    }
}


require "partials/header.php";
require "partials/sidebar.php";

?>

<h5>My Profile</h5>


<div class="card p-4 mt-3" style="max-width:720px">


    <!-- PROFILE PHOTO -->

    <div class="d-flex align-items-center mb-4">

        <?php if (!empty($u["profile_pic"])): ?>

            <img
                src="<?= e($u["profile_pic"]) ?>"
                alt="Profile Picture"
                style="
                    width:90px;
                    height:90px;
                    object-fit:cover;
                    border-radius:50%;
                    border:3px solid #eee;
                "
            >

        <?php else: ?>

            <div
                style="
                    width:90px;
                    height:90px;
                    border-radius:50%;
                    background:#f1f1f1;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    font-size:45px;
                "
            >
                👤
            </div>

        <?php endif; ?>


        <div class="ms-3">

            <h5>
                <?= e($u["full_name"]) ?>
            </h5>

            <small>
                <?= e($u["role"]) ?>

                <?php if (!empty($u["member_code"])): ?>
                    | <?= e($u["member_code"]) ?>
                <?php endif; ?>
            </small>

        </div>

    </div>


    <!-- SUCCESS MESSAGE -->

    <?php if ($msg): ?>

        <div class="alert alert-success">
            <?= e($msg) ?>
        </div>

    <?php endif; ?>


    <!-- ERROR MESSAGE -->

    <?php if ($error): ?>

        <div class="alert alert-danger">
            <?= e($error) ?>
        </div>

    <?php endif; ?>


    <!-- FORM -->

    <form
        method="post"
        enctype="multipart/form-data"
    >

        <div class="row g-3">


            <!-- FULL NAME -->

            <div class="col-md-6">

                <label>Full Name</label>

                <input
                    class="form-control"
                    name="full_name"
                    value="<?= e($u["full_name"]) ?>"
                    required
                >

            </div>


            <!-- EMAIL -->

            <div class="col-md-6">

                <label>Email</label>

                <input
                    class="form-control"
                    value="<?= e($u["email"]) ?>"
                    disabled
                >

            </div>


            <!-- MOBILE -->

            <div class="col-md-6">

                <label>Mobile</label>

                <input
                    class="form-control"
                    name="mobile"
                    value="<?= e($u["mobile"]) ?>"
                >

            </div>


            <!-- PASSWORD -->

            <div class="col-md-6">

                <label>New Password</label>

                <input
                    class="form-control"
                    type="password"
                    name="password"
                    placeholder="Leave blank to keep current"
                >

            </div>


            <!-- PROFILE PICTURE -->

            <div class="col-md-6">

                <label>Profile Picture</label>

                <input
                    class="form-control"
                    type="file"
                    name="file"
                    accept="image/jpeg,image/png,image/webp"
                >

                <small class="text-muted">
                    JPG, PNG or WEBP — Maximum 2MB
                </small>

            </div>


        </div>


        <div class="col-md-6">
                <label>Chatbot Language</label>
                <select class="form-select" name="preferred_language">
                    <option value="auto" <?=($u["preferred_language"]??"auto")==="auto"?"selected":""?>>Auto Detect</option>
                    <option value="en" <?=($u["preferred_language"]??"")==="en"?"selected":""?>>English</option>
                    <option value="hi" <?=($u["preferred_language"]??"")==="hi"?"selected":""?>>हिन्दी</option>
                    <option value="es" <?=($u["preferred_language"]??"")==="es"?"selected":""?>>Español</option>
                    <option value="fr" <?=($u["preferred_language"]??"")==="fr"?"selected":""?>>Français</option>
                    <option value="de" <?=($u["preferred_language"]??"")==="de"?"selected":""?>>Deutsch</option>
                    <option value="bn" <?=($u["preferred_language"]??"")==="bn"?"selected":""?>>বাংলা</option>
                    <option value="mr" <?=($u["preferred_language"]??"")==="mr"?"selected":""?>>मराठी</option>
                </select>
            </div>

        <!-- BUTTON -->

        <button
            type="submit"
            class="btn btn-primary mt-3"
        >
            Edit Profile
        </button>

    </form>

</div>


<?php require "partials/footer.php"; ?>