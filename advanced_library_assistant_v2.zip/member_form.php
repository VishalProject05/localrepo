<?php
require_once "auth.php";
requireAdmin();
$id = (int)($_GET["id"] ?? 0);
$m = $id ? $pdo->query("SELECT * FROM users WHERE id=$id AND role<>'Admin'")->fetch() : null;
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["full_name"]);
    $email = trim($_POST["email"]);
    $mobile = trim($_POST["mobile"]);
    $role = $_POST["role"] === "Staff" ? "Staff" : "Student";
    if ($id) {
        $st = $pdo->prepare("UPDATE users SET full_name=?,email=?,mobile=?,role=? WHERE id=?");
        $st->execute([$name,$email,$mobile,$role,$id]);
    } else {
        $count = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role<>'Admin'")->fetchColumn() + 1;
        $code = "M".str_pad($count, 3, "0", STR_PAD_LEFT);
        $st = $pdo->prepare("INSERT INTO users(full_name,email,mobile,password,role,member_code,created_at) VALUES(?,?,?,?,?,?,CURDATE())");
        $st->execute([$name,$email,$mobile,password_hash($_POST["password"], PASSWORD_DEFAULT),$role,$code]);
    }
    header("Location:members.php");
    exit;
}
require "partials/header.php";
require "partials/sidebar.php";?><h5><?=$id ? "Edit Member" : "Add Member"?></h5><div class="card p-4 mt-3"><form method="post"><div class="row g-3"><div class="col-md-6"><label>Full Name</label><input class="form-control" name="full_name" required value="<?=e($m["full_name"] ?? "")?>"></div><div class="col-md-6"><label>Email</label><input class="form-control" type="email" name="email" required value="<?=e($m["email"] ?? "")?>"></div><div class="col-md-6"><label>Mobile</label><input class="form-control" name="mobile" value="<?=e($m["mobile"] ?? "")?>"></div><div class="col-md-3"><label>Role</label><select class="form-select" name="role"><option <?=($m["role"] ?? "Student") === "Student" ? "selected" : ""?>>Student</option><option <?=($m["role"] ?? "") === "Staff" ? "selected" : ""?>>Staff</option></select></div><?php if (!$id):?><div class="col-md-6"><label>Password</label><input class="form-control" type="password" name="password" required minlength="6"></div><?php endif;?></div><button class="btn btn-primary mt-3">Save Member</button></form></div><?php require "partials/footer.php"; ?>