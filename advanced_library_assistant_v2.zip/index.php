<?php

require_once "auth.php";
if (isLoggedIn()) {
    header("Location: ".($_SESSION["role"] === "Admin" ? "admin_dashboard.php" : "member_dashboard.php"));
} else {
    header("Location: login.php");
}
exit;
