<?php
require_once "auth.php";
requireLogin();
$id = (int)($_GET['id'] ?? 0);
$st = $pdo->prepare("SELECT * FROM books WHERE id=?"); $st->execute([$id]); $b=$st->fetch();
if (!$b) { http_response_code(404); exit('Book not found.'); }
if (!empty($b['purchase_url'])) { header('Location: '.$b['purchase_url']); exit; }
if ((float)$b['price'] <= 0) { header('Location: book_details.php?id='.$id); exit; }
$_SESSION['cart'] = $_SESSION['cart'] ?? [];
$_SESSION['cart'][$id] = ($_SESSION['cart'][$id] ?? 0) + 1;
header('Location: cart.php'); exit;
