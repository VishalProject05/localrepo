<?php
require_once "auth.php";
requireLogin();
header("Content-Type: application/json; charset=UTF-8");

$q = trim($_POST['message'] ?? '');
if ($q === '') { echo json_encode(['reply'=>'Please type a question.']); exit; }
$role=$_SESSION['role']; $uid=(int)$_SESSION['user_id'];
$lang = strtolower(trim($_POST['language'] ?? ($_SESSION['preferred_language'] ?? 'auto')));
$allowed=['auto','en','hi','es','fr','de','bn','mr']; if(!in_array($lang,$allowed,true))$lang='auto';
$text=mb_strtolower($q,'UTF-8');

function detectLang(string $t): string {
    if (preg_match('/[\x{0900}-\x{097F}]/u',$t)) return 'hi';
    if (preg_match('/[\x{0980}-\x{09FF}]/u',$t)) return 'bn';
    $sets=[
      'es'=>['hola','libro','libros','comprar','descargar','devolver','contraseña','quiero','ayuda','disponible'],
      'fr'=>['bonjour','livre','acheter','télécharger','retourner','mot de passe','aide','disponible'],
      'de'=>['hallo','buch','bücher','kaufen','herunterladen','zurückgeben','passwort','hilfe','verfügbar'],
      'mr'=>['पुस्तक','मला','पाहिजे','खरेदी','डाउनलोड','परत','पासवर्ड']
    ];
    foreach($sets as $l=>$words){foreach($words as $w){if(mb_strpos($t,$w)!==false)return $l;}}
    return 'en';
}
if($lang==='auto') $lang=detectLang($text);
$_SESSION['chat_lang']=$lang;

$T=[
'en'=>[
 'hello'=>'Hello! I can search books, show availability, help with issue/return, shopping, orders, PDFs and account questions.',
 'empty'=>'Please type a question.', 'notfound'=>'I could not find a matching book. Try the title, author, subject or language.',
 'login'=>'Open the Login page and use your registered email and password. Use Forgot password if needed.',
 'password'=>'Use Forgot password on the Login page to reset your password.',
 'issue'=>'For a physical library book, open Issue / Return and send an Issue Request. I can also help you find an available title.',
 'return'=>'Open My Books and request a return for an issued book. An admin must approve the return.',
 'profile'=>'Open Profile to update your name, mobile, profile picture and chatbot language.',
 'cart'=>'Your shopping cart is available from the 🛒 icon or the Search & Shop page.',
 'orders'=>'Open My Orders to see your purchases and order status.',
 'admin'=>'Admin tools include pending issue/return requests, book management, PDFs, reports and orders.',
 'unknown'=>'I can help with books, availability, issue/return, shopping, PDFs, orders, profile, login and notifications.'
],
'hi'=>[
 'hello'=>'नमस्ते! मैं books search, availability, issue/return, shopping, orders, PDFs और account में मदद कर सकता हूँ।','empty'=>'कृपया सवाल लिखें।','notfound'=>'मुझे matching book नहीं मिली। Title, author, subject या language लिखकर फिर कोशिश करें।','login'=>'Login page खोलें और registered email/password डालें। जरूरत हो तो Forgot password इस्तेमाल करें।','password'=>'Login page पर Forgot password खोलकर password reset करें।','issue'=>'Physical library book के लिए Issue / Return खोलकर Issue Request भेजें। मैं available book भी खोज सकता हूँ।','return'=>'My Books में जाकर issued book के सामने return request भेजें। Admin approval के बाद return complete होगा।','profile'=>'Profile में name, mobile, profile picture और chatbot language बदल सकते हैं।','cart'=>'🛒 icon या Search & Shop से shopping cart खोलें।','orders'=>'My Orders में अपने purchases और order status देखें।','admin'=>'Admin को pending issue/return, books, PDFs, reports और orders manage करने की सुविधा है।','unknown'=>'मैं books, availability, issue/return, shopping, PDFs, orders, profile, login और notifications में मदद कर सकता हूँ।'
],
'es'=>[
 'hello'=>'¡Hola! Puedo buscar libros, comprobar disponibilidad, ayudarte con préstamos/devoluciones, compras, pedidos, PDFs y tu cuenta.','empty'=>'Escribe una pregunta, por favor.','notfound'=>'No encontré un libro coincidente. Prueba con título, autor, tema o idioma.','login'=>'Abre Login y usa tu correo y contraseña registrados. Usa Forgot password si lo necesitas.','password'=>'Usa Forgot password en Login para restablecer tu contraseña.','issue'=>'Para un libro físico, abre Issue / Return y envía una solicitud de préstamo. También puedo buscar libros disponibles.','return'=>'Abre My Books y solicita la devolución del libro prestado. Un administrador debe aprobarla.','profile'=>'En Profile puedes cambiar nombre, móvil, foto y el idioma del chatbot.','cart'=>'Abre el carrito desde el icono 🛒 o Search & Shop.','orders'=>'Abre My Orders para ver compras y estado de pedidos.','admin'=>'El administrador puede gestionar solicitudes, libros, PDFs, informes y pedidos.','unknown'=>'Puedo ayudarte con libros, disponibilidad, préstamos, devoluciones, compras, PDFs, pedidos, perfil y login.'
],
'fr'=>[
 'hello'=>'Bonjour ! Je peux rechercher des livres, vérifier la disponibilité, aider pour les prêts/retours, les achats, les commandes, les PDF et le compte.','empty'=>'Veuillez saisir une question.','notfound'=>'Aucun livre correspondant. Essayez le titre, l’auteur, le sujet ou la langue.','login'=>'Ouvrez Login et utilisez votre e-mail et votre mot de passe enregistrés.','password'=>'Utilisez Forgot password sur Login pour réinitialiser le mot de passe.','issue'=>'Pour un livre physique, ouvrez Issue / Return et envoyez une demande de prêt.','return'=>'Ouvrez My Books et demandez le retour du livre. Un administrateur doit l’approuver.','profile'=>'Dans Profile, vous pouvez modifier le nom, le mobile, la photo et la langue du chatbot.','cart'=>'Ouvrez le panier avec l’icône 🛒 ou Search & Shop.','orders'=>'Ouvrez My Orders pour voir vos achats et commandes.','admin'=>'L’administrateur peut gérer les demandes, livres, PDF, rapports et commandes.','unknown'=>'Je peux aider avec les livres, la disponibilité, les prêts/retours, les achats, les PDF, les commandes et le profil.'
],
'de'=>[
 'hello'=>'Hallo! Ich kann Bücher suchen, Verfügbarkeit prüfen und bei Ausleihe, Rückgabe, Einkauf, Bestellungen, PDFs und Konto helfen.','empty'=>'Bitte geben Sie eine Frage ein.','notfound'=>'Kein passendes Buch gefunden. Versuchen Sie Titel, Autor, Thema oder Sprache.','login'=>'Öffnen Sie Login und verwenden Sie Ihre registrierte E-Mail und Ihr Passwort.','password'=>'Verwenden Sie Forgot password auf der Login-Seite.','issue'=>'Für ein physisches Buch öffnen Sie Issue / Return und senden Sie eine Ausleihanfrage.','return'=>'Öffnen Sie My Books und beantragen Sie die Rückgabe. Ein Admin muss sie bestätigen.','profile'=>'Unter Profile können Sie Name, Mobilnummer, Foto und Chatbot-Sprache ändern.','cart'=>'Öffnen Sie den Warenkorb über 🛒 oder Search & Shop.','orders'=>'Unter My Orders sehen Sie Käufe und Bestellstatus.','admin'=>'Admins können Anfragen, Bücher, PDFs, Berichte und Bestellungen verwalten.','unknown'=>'Ich kann bei Büchern, Verfügbarkeit, Ausleihe/Rückgabe, Einkauf, PDFs, Bestellungen und Profil helfen.'
],
'bn'=>[
 'hello'=>'নমস্কার! আমি বই খোঁজা, availability, issue/return, shopping, order, PDF এবং profile বিষয়ে সাহায্য করতে পারি।','empty'=>'দয়া করে প্রশ্ন লিখুন।','notfound'=>'মিলছে এমন বই পাওয়া যায়নি। title, author, subject বা language লিখুন।','login'=>'Login পেজে registered email ও password ব্যবহার করুন।','password'=>'Login পেজের Forgot password দিয়ে password reset করুন।','issue'=>'Issue / Return খুলে বইয়ের জন্য Issue Request পাঠান।','return'=>'My Books থেকে return request পাঠান; Admin অনুমোদন করবে।','profile'=>'Profile থেকে নাম, mobile, ছবি এবং chatbot language বদলাতে পারবেন।','cart'=>'🛒 icon বা Search & Shop থেকে cart খুলুন।','orders'=>'My Orders থেকে purchase ও order status দেখুন।','admin'=>'Admin requests, books, PDFs, reports এবং orders manage করতে পারে।','unknown'=>'আমি books, availability, issue/return, shopping, PDFs, orders, profile ও login বিষয়ে সাহায্য করতে পারি।'
],
'mr'=>[
 'hello'=>'नमस्कार! मी पुस्तके शोधणे, उपलब्धता, issue/return, shopping, orders, PDFs आणि profile मध्ये मदत करू शकतो.','empty'=>'कृपया प्रश्न लिहा.','notfound'=>'जुळणारे पुस्तक सापडले नाही. title, author, subject किंवा language लिहा.','login'=>'Login page वर registered email आणि password वापरा.','password'=>'Login page वरील Forgot password वापरा.','issue'=>'Issue / Return उघडून पुस्तकासाठी Issue Request पाठवा.','return'=>'My Books मधून return request पाठवा; Admin मंजूर करेल.','profile'=>'Profile मध्ये नाव, mobile, फोटो आणि chatbot language बदलू शकता.','cart'=>'🛒 icon किंवा Search & Shop मधून cart उघडा.','orders'=>'My Orders मध्ये purchases आणि order status पहा.','admin'=>'Admin requests, books, PDFs, reports आणि orders manage करू शकतो.','unknown'=>'मी books, availability, issue/return, shopping, PDFs, orders, profile आणि login मध्ये मदत करू शकतो.'
]
];
$t=$T[$lang]??$T['en'];

function bookCards(array $books, array $t): string {
  if(!$books) return $t['notfound'];
  $html='<div class="chat-book-results">';
  foreach($books as $i=>$b){
    $html.='<div class="chat-book-card"><b>'.e($b['title']).'</b><div class="small">'.e($b['author']).' · '.e($b['language']??'English').'</div>';
    if((int)$b['total_copies']>0)$html.='<div class="small mt-1">Available: '.e($b['available_copies']).'</div>';
    if((float)$b['price']>0)$html.='<div class="fw-bold mt-1">'.e($b['currency']).' '.number_format((float)$b['price'],2).'</div>';
    $html.='<div class="d-flex gap-1 mt-2"><a class="btn btn-sm btn-outline-primary" href="book_details.php?id='.$b['id'].'">Details</a>';
    if(!empty($b['purchase_url']))$html.='<a class="btn btn-sm btn-warning" target="_blank" rel="noopener" href="'.e($b['purchase_url']).'">Buy</a>';
    elseif((float)$b['price']>0)$html.='<a class="btn btn-sm btn-primary" href="buy.php?id='.$b['id'].'">Buy</a>';
    if(!empty($b['digital_file']))$html.='<a class="btn btn-sm btn-success" href="download.php?id='.$b['id'].'">PDF</a>';
    $html.='</div></div>';
    if($i>=7)break;
  }
  return $html.'</div>';
}

// Book search intent
$bookWords=['book','books','book chahiye','kitab','libro','livre','buch','पुस्तक','किताब','libros','livres','bücher'];
$isBook=false;foreach($bookWords as $w){if(mb_strpos($text,$w)!==false){$isBook=true;break;}}
if($isBook || preg_match('/\b(java|python|php|c programming|osho|meditation|database|network|computer|programming)\b/i',$text)){
  $search=preg_replace('/\b(show|find|search|give|need|want|available|books?|chahiye|dikhao|dikhाओ|mujhe|koi|book|books|libro|livres|buch|bücher|pustak|पुस्तक|किताब|quiero|libro|livre|buch)\b/iu',' ',$q);$search=trim(preg_replace('/\s+/',' ',$search));
  if($search===''){$books=$pdo->query("SELECT * FROM books ORDER BY CASE WHEN available_copies>0 THEN 0 ELSE 1 END,title LIMIT 8")->fetchAll();}
  else{$like='%'.$search.'%';$st=$pdo->prepare("SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR category LIKE ? OR language LIKE ? ORDER BY CASE WHEN available_copies>0 THEN 0 ELSE 1 END,title LIMIT 8");$st->execute([$like,$like,$like,$like]);$books=$st->fetchAll();}
  $_SESSION['chat_last_books']=array_column($books,'id');
  $prefix=['en'=>'Here are matching books:','hi'=>'Matching books ये हैं:','es'=>'Estos son los libros encontrados:','fr'=>'Voici les livres trouvés :','de'=>'Hier sind passende Bücher:','bn'=>'মিল পাওয়া বইগুলো:','mr'=>'जुळणारी पुस्तके:'][$lang]??'Here are matching books:';
  echo json_encode(['reply'=>'<div>'.$prefix.'</div>'.bookCards($books,$t),'language'=>$lang],JSON_UNESCAPED_UNICODE);exit;
}

// Actions / stats
if(preg_match('/\b(hello|hi|hey|hola|bonjour|hallo|namaste|नमस्ते|नमस्कार)\b/iu',$text)){echo json_encode(['reply'=>$t['hello'],'language'=>$lang]);exit;}
if(str_contains($text,'password')||str_contains($text,'forgot')||str_contains($text,'contraseña')||str_contains($text,'mot de passe')||str_contains($text,'passwort')||str_contains($text,'भूल'))$reply=$t['password'];
elseif(str_contains($text,'login')||str_contains($text,'connexion')||str_contains($text,'anmelden')||str_contains($text,'लॉगिन'))$reply=$t['login'];
elseif(str_contains($text,'return')||str_contains($text,'वापस')||str_contains($text,'devolver')||str_contains($text,'retour')||str_contains($text,'zurück'))$reply=$t['return'];
elseif(str_contains($text,'issue')||str_contains($text,'borrow')||str_contains($text,'request')||str_contains($text,'lending')||str_contains($text,'auslei')||str_contains($text,'prêt'))$reply=$t['issue'];
elseif(str_contains($text,'profile')||str_contains($text,'photo')||str_contains($text,'picture'))$reply=$t['profile'];
elseif(str_contains($text,'cart')||str_contains($text,'shopping')||str_contains($text,'buy')||str_contains($text,'comprar')||str_contains($text,'acheter')||str_contains($text,'kaufen'))$reply=$t['cart'];
elseif(str_contains($text,'order')||str_contains($text,'pedido')||str_contains($text,'commande')||str_contains($text,'bestellung'))$reply=$t['orders'];
elseif($role==='Admin' && (str_contains($text,'pending')||str_contains($text,'admin')||str_contains($text,'statistics')||str_contains($text,'stats'))){$a=(int)$pdo->query("SELECT COUNT(*) FROM issue_requests WHERE status='Pending'")->fetchColumn();$r=(int)$pdo->query("SELECT COUNT(*) FROM return_requests WHERE status='Pending'")->fetchColumn();$o=(int)$pdo->query("SELECT COUNT(*) FROM orders WHERE order_status IN ('Placed','Processing')")->fetchColumn();$reply="Admin summary: {$a} pending issue requests, {$r} pending return requests and {$o} active orders.";}
elseif(str_contains($text,'my books')||str_contains($text,'issued')||str_contains($text,'मेरी किताब')){$st=$pdo->prepare("SELECT b.title,ir.return_date,ir.status FROM issue_returns ir JOIN books b ON b.id=ir.book_id WHERE ir.member_id=? AND ir.status<>'Returned' ORDER BY ir.issue_date DESC");$st->execute([$uid]);$rows=$st->fetchAll();if(!$rows)$reply='No active issued books.';else{$reply='<b>My active books:</b><ul>';foreach($rows as $r)$reply.='<li>'.e($r['title']).' — '.e($r['status']).' — return '.e($r['return_date']).'</li>';$reply.='</ul>';}}
else $reply=$t['unknown'];
echo json_encode(['reply'=>$reply,'language'=>$lang],JSON_UNESCAPED_UNICODE);
