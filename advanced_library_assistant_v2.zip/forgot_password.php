<?php
require_once "config.php";
$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $mobile = trim($_POST["mobile"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirmPassword = $_POST["confirm_password"] ?? "";

    if ($password !== $confirmPassword) {
        $error = "Passwords do not match.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters.";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email=? AND mobile=? LIMIT 1");
        $stmt->execute([$email, $mobile]);
        $user = $stmt->fetch();
        if (!$user) {
            $error = "Email and mobile number did not match.";
        } else {
            $stmt = $pdo->prepare("UPDATE users SET password=? WHERE id=?");
            $stmt->execute([password_hash($password, PASSWORD_DEFAULT), $user["id"]]);
            $message = "Password reset successfully. You can now login.";
        }
    }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Reset Password - Online Library</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="auth-bg">
<div class="auth-box">
<h5 class="text-center">Reset Password</h5>
<p class="text-center text-muted small">Verify your account to create a new password</p>
<?php if ($message): ?><div class="alert alert-success py-2"><?=htmlspecialchars($message, ENT_QUOTES, "UTF-8")?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger py-2"><?=htmlspecialchars($error, ENT_QUOTES, "UTF-8")?></div><?php endif; ?>
<form method="post">
<label class="small">Email</label>
<input class="form-control mb-3" type="email" name="email" required>
<label class="small">Registered Mobile Number</label>
<input class="form-control mb-3" type="text" name="mobile" required>
<label class="small">New Password</label>
<input class="form-control mb-3" type="password" name="password" minlength="6" required>
<label class="small">Confirm New Password</label>
<input class="form-control mb-3" type="password" name="confirm_password" minlength="6" required>
<button class="btn btn-primary w-100">Reset Password</button>
</form>
<p class="small text-center mt-3 mb-0"><a href="login.php">Back to Login</a></p>
</div>
</body>
</html>
