<?php
require_once "auth.php";
requireAdmin();
$pageTitle = "Dashboard";
$totalBooks = (int)$pdo->query("SELECT COALESCE(SUM(total_copies),0) FROM books")->fetchColumn();
$available = (int)$pdo->query("SELECT COALESCE(SUM(available_copies),0) FROM books")->fetchColumn();
$totalMembers = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role<>'Admin'")->fetchColumn();
$issued = (int)$pdo->query("SELECT COUNT(*) FROM issue_returns WHERE status='Issued'")->fetchColumn();
$returned = (int)$pdo->query("SELECT COUNT(*) FROM issue_returns WHERE status='Returned'")->fetchColumn();
$overdue = (int)$pdo->query("SELECT COUNT(*) FROM issue_returns WHERE status='Issued' AND return_date<CURDATE()")->fetchColumn();
$activities = $pdo->query("SELECT ir.*,u.full_name,b.title FROM issue_returns ir JOIN users u ON u.id=ir.member_id JOIN books b ON b.id=ir.book_id ORDER BY ir.id DESC LIMIT 5")->fetchAll();
$popular = $pdo->query("SELECT b.title,COUNT(ir.id) c FROM books b LEFT JOIN issue_returns ir ON ir.book_id=b.id GROUP BY b.id ORDER BY c DESC LIMIT 5")->fetchAll();
require "partials/header.php";
require "partials/sidebar.php"; ?>
<h4 class="fw-bold">Dashboard</h4><div class="row g-3 mt-1">
<div class="col-md-3"><div class="stat blue"><div>📖 &nbsp; Total Books</div><h2><?=$totalBooks?></h2><small>Available: <?=$available?> | Issued: <?=$totalBooks - $available?></small></div></div>
<div class="col-md-3"><div class="stat green"><div>👥 &nbsp; Total Members</div><h2><?=$totalMembers?></h2><small>Students & Staff</small></div></div>
<div class="col-md-3"><div class="stat orange"><div>▣ &nbsp; Books Issued</div><h2><?=$issued?></h2><small>This month</small></div></div>
<div class="col-md-3"><div class="stat purple"><div>↩ &nbsp; Books Returned</div><h2><?=$returned?></h2><small>Total returned</small></div></div><div class="col-md-3"><div class="stat" style="background:#d64545"><div>⚠ &nbsp; Overdue Books</div><h2><?=$overdue?></h2><small>Past due date</small></div></div></div>
<div class="row g-3 mt-2"><div class="col-lg-9"><div class="card p-3"><h6>Recent Activities</h6><div class="table-responsive"><table class="table table-hover"><thead><tr><th>#</th><th>Member Name</th><th>Book Name</th><th>Issue Date</th><th>Return Date</th><th>Status</th></tr></thead><tbody>
<?php foreach ($activities as $i => $a): ?><tr><td><?=$i + 1?></td><td><?=e($a["full_name"])?></td><td><?=e($a["title"])?></td><td><?=e($a["issue_date"])?></td><td><?=e($a["return_date"])?></td><td><span class="badge-soft"><?=e($a["status"])?></span></td></tr><?php endforeach; ?>
</tbody></table></div></div></div><div class="col-lg-3"><div class="card p-3"><h6>Quick Actions</h6><a class="btn btn-primary btn-sm w-100 mb-2" href="book_form.php">Add Book</a><a class="btn btn-outline-primary btn-sm w-100 mb-2" href="digital_library.php">Manage Digital PDFs</a><a class="btn btn-outline-primary btn-sm w-100" href="issue_return.php">Issue / Return</a></div><div class="card p-3 mt-3"><h6>Popular Books</h6><?php foreach ($popular as $p): ?><div class="d-flex justify-content-between border-bottom py-2 small"><span>📖 <?=e($p["title"])?></span><b><?=$p["c"]?> times</b></div><?php endforeach; ?></div></div></div>
<?php require "partials/footer.php"; ?>