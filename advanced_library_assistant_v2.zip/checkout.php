<?php
require_once "auth.php"; requireLogin();
$pageTitle='Checkout'; $_SESSION['cart']=$_SESSION['cart']??[];
if(!$_SESSION['cart']){header('Location: cart.php');exit;}
$ids=array_keys($_SESSION['cart']);$in=implode(',',array_fill(0,count($ids),'?'));$st=$pdo->prepare("SELECT * FROM books WHERE id IN ($in)");$st->execute($ids);$books=$st->fetchAll();$total=0;
foreach($books as $b){$total+=(float)$b['price']*max(1,(int)$_SESSION['cart'][$b['id']]);}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $method=$_POST['payment_method']??'Cash on Delivery';$address=trim($_POST['shipping_address']??'');
 if(!in_array($method,['Cash on Delivery','UPI / Bank Transfer']))$error='Invalid payment method.';
 elseif($address==='')$error='Please enter your delivery address.';
 else{
  $pdo->beginTransaction();
  try{
   $st=$pdo->prepare("INSERT INTO orders(user_id,total_amount,currency,payment_method,shipping_address) VALUES(?,?,?,?,?)");$st->execute([$_SESSION['user_id'],$total,$books[0]['currency']??'INR',$method,$address]);$oid=(int)$pdo->lastInsertId();
   $it=$pdo->prepare("INSERT INTO order_items(order_id,book_id,quantity,unit_price) VALUES(?,?,?,?)");
   foreach($books as $b){$it->execute([$oid,$b['id'],max(1,(int)$_SESSION['cart'][$b['id']]),$b['price']]);}
   $pdo->commit();$_SESSION['cart']=[];header('Location: orders.php?placed='.$oid);exit;
  }catch(Throwable $e){$pdo->rollBack();$error='Unable to place order right now.';}
 }
}
require 'partials/header.php';require 'partials/sidebar.php'; ?>
<h5>Checkout</h5><div class="card p-4 mt-3" style="max-width:850px"><?php if($error): ?><div class="alert alert-danger"><?=e($error)?></div><?php endif; ?><h6>Order Summary</h6><ul class="list-group mb-4"><?php foreach($books as $b): ?><li class="list-group-item d-flex justify-content-between"><span><?=e($b['title'])?> × <?=max(1,(int)$_SESSION['cart'][$b['id']])?></span><b><?=e($b['currency'])?> <?=number_format((float)$b['price']*max(1,(int)$_SESSION['cart'][$b['id']]),2)?></b></li><?php endforeach; ?><li class="list-group-item d-flex justify-content-between"><b>Total</b><b><?=e($books[0]['currency']??'INR')?> <?=number_format($total,2)?></b></li></ul><form method="post"><label>Delivery Address</label><textarea name="shipping_address" class="form-control" rows="3" required placeholder="Full address"></textarea><label class="mt-3">Payment Method</label><select name="payment_method" class="form-select"><option>Cash on Delivery</option><option>UPI / Bank Transfer</option></select><button class="btn btn-success mt-3">Place Order</button><a class="btn btn-light mt-3 ms-2" href="cart.php">Back to Cart</a></form></div><?php require 'partials/footer.php'; ?>
