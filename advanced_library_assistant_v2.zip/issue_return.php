<?php
require_once "auth.php";
requireLogin();
$currentUser = $pdo->prepare("SELECT id,role FROM users WHERE id=?");
$currentUser->execute([(int)$_SESSION["user_id"]]);
$currentUser = $currentUser->fetch();
if (!$currentUser) {
    session_unset();
    session_destroy();
    header("Location:login.php");
    exit;
}
$_SESSION["role"] = $currentUser["role"];
$pageTitle = "Issue / Return Books";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST["action"] ?? "";
    $bookId = (int)($_POST["book_id"] ?? 0);

    if ($action === "request" && $_SESSION["role"] !== "Admin") {
        $check = $pdo->prepare("SELECT id FROM issue_requests WHERE member_id=? AND book_id=? AND status='Pending'");
        $check->execute([$currentUser["id"], $bookId]);
        if ($check->fetch()) {
            $error = "You already have a pending request for this book.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO issue_requests(member_id,book_id) VALUES(?,?)");
            $stmt->execute([$currentUser["id"], $bookId]);
            flash("success", "Book issue request sent to Admin.");
        }
    } elseif ($action === "return_request" && $_SESSION["role"] !== "Admin") {
        $issueId = (int)($_POST["issue_id"] ?? 0);
        $check = $pdo->prepare("SELECT id FROM issue_returns WHERE id=? AND member_id=? AND status='Issued'");
        $check->execute([$issueId, $currentUser["id"]]);
        if ($check->fetch()) {
            $check = $pdo->prepare("SELECT id FROM return_requests WHERE issue_id=? AND status='Pending'");
            $check->execute([$issueId]);
            if ($check->fetch()) {
                $error = "You already have a pending return request.";
            } else {
                $stmt = $pdo->prepare("INSERT INTO return_requests(issue_id,member_id) VALUES(?,?)");
                $stmt->execute([$issueId, $currentUser["id"]]);
                flash("success", "Return request sent to Admin.");
            }
        }
    } elseif ($action === "approve_return" && $_SESSION["role"] === "Admin") {
        $requestId = (int)($_POST["return_request_id"] ?? 0);
        $stmt = $pdo->prepare("SELECT issue_id FROM return_requests WHERE id=? AND status='Pending'");
        $stmt->execute([$requestId]);
        $returnRequest = $stmt->fetch();
        if ($returnRequest) {
            $stmt = $pdo->prepare("SELECT book_id FROM issue_returns WHERE id=? AND status='Issued'");
            $stmt->execute([$returnRequest["issue_id"]]);
            $row = $stmt->fetch();
            if ($row) {
                $pdo->beginTransaction();
                $fineStmt = $pdo->prepare("SELECT GREATEST(DATEDIFF(CURDATE(), return_date), 0) * 10 FROM issue_returns WHERE id=?");
                $fineStmt->execute([$returnRequest["issue_id"]]);
                $fine = (float)$fineStmt->fetchColumn();
                $pdo->prepare("UPDATE issue_returns SET actual_return_date=CURDATE(),status='Returned',fine=?,remarks=? WHERE id=?")->execute([$fine, $fine > 0 ? "Late return" : "Returned on time", $returnRequest["issue_id"]]);
                $pdo->prepare("UPDATE books SET available_copies=available_copies+1 WHERE id=?")->execute([$row["book_id"]]);
                $pdo->prepare("UPDATE return_requests SET status='Approved' WHERE id=?")->execute([$requestId]);
                $pdo->commit();
                flash("success", "Return request approved.");
            }
        }
    } elseif ($action === "reject_return" && $_SESSION["role"] === "Admin") {
        $stmt = $pdo->prepare("UPDATE return_requests SET status='Rejected' WHERE id=? AND status='Pending'");
        $stmt->execute([(int)($_POST["return_request_id"] ?? 0)]);
        flash("success", "Return request rejected.");
    } elseif ($action === "approve" && $_SESSION["role"] === "Admin") {
        $requestId = (int)($_POST["request_id"] ?? 0);
        $stmt = $pdo->prepare("SELECT member_id,book_id FROM issue_requests WHERE id=? AND status='Pending'");
        $stmt->execute([$requestId]);
        $request = $stmt->fetch();
        if ($request) {
            $available = $pdo->prepare("SELECT available_copies FROM books WHERE id=?");
            $available->execute([$request["book_id"]]);
            if ((int)$available->fetchColumn() > 0) {
                $pdo->beginTransaction();
                $issue = $pdo->prepare("INSERT INTO issue_returns(member_id,book_id,issue_date,return_date,status) VALUES(?,?,CURDATE(),DATE_ADD(CURDATE(), INTERVAL 14 DAY),'Issued')");
                $issue->execute([$request["member_id"], $request["book_id"]]);
                $pdo->prepare("UPDATE books SET available_copies=available_copies-1 WHERE id=?")->execute([$request["book_id"]]);
                $pdo->prepare("UPDATE issue_requests SET status='Approved' WHERE id=?")->execute([$requestId]);
                $pdo->commit();
                flash("success", "Issue request approved.");
            } else {
                $error = "Book is no longer available.";
            }
        }
    } elseif ($action === "reject" && $_SESSION["role"] === "Admin") {
        $stmt = $pdo->prepare("UPDATE issue_requests SET status='Rejected' WHERE id=? AND status='Pending'");
        $stmt->execute([(int)($_POST["request_id"] ?? 0)]);
        flash("success", "Issue request rejected.");
    } elseif ($action === "return" && $_SESSION["role"] === "Admin") {
        $issueId = (int)($_POST["issue_id"] ?? 0);
        $stmt = $pdo->prepare("SELECT book_id FROM issue_returns WHERE id=? AND status='Issued'");
        $stmt->execute([$issueId]);
        $row = $stmt->fetch();
        if ($row) {
            $pdo->beginTransaction();
            $fineStmt = $pdo->prepare("SELECT GREATEST(DATEDIFF(CURDATE(), return_date), 0) * 10 FROM issue_returns WHERE id=?");
            $fineStmt->execute([$issueId]);
            $fine = (float)$fineStmt->fetchColumn();
            $pdo->prepare("UPDATE issue_returns SET actual_return_date=CURDATE(),status='Returned',fine=?,remarks=? WHERE id=?")->execute([$fine, $fine > 0 ? "Late return" : "Returned on time", $issueId]);
            $pdo->prepare("UPDATE books SET available_copies=available_copies+1 WHERE id=?")->execute([$row["book_id"]]);
            $pdo->commit();
            flash("success", "Book returned successfully.");
        }
    } elseif ($action === "issue" && $_SESSION["role"] === "Admin") {
        $memberId = (int)($_POST["member_id"] ?? 0);
        $issueDate = $_POST["issue_date"] ?? date("Y-m-d");
        $returnDate = $_POST["return_date"] ?? date("Y-m-d", strtotime("+14 days"));
        $stmt = $pdo->prepare("SELECT available_copies FROM books WHERE id=?");
        $stmt->execute([$bookId]);
        if ((int)$stmt->fetchColumn() > 0) {
            $pdo->beginTransaction();
            $pdo->prepare("INSERT INTO issue_returns(member_id,book_id,issue_date,return_date,status) VALUES(?,?,?,?, 'Issued')")->execute([$memberId, $bookId, $issueDate, $returnDate]);
            $pdo->prepare("UPDATE books SET available_copies=available_copies-1 WHERE id=?")->execute([$bookId]);
            $pdo->commit();
            flash("success", "Book issued successfully.");
        } else {
            $error = "Book is not available.";
        }
    }
    if ($action !== "") {
        header("Location:issue_return.php");
        exit;
    }
}

$members = $pdo->query("SELECT id,full_name,member_code FROM users WHERE role<>'Admin' ORDER BY full_name")->fetchAll();
$books = $pdo->query("SELECT id,title,available_copies FROM books WHERE available_copies>0 ORDER BY title")->fetchAll();
$requests = [];
$returnRequests = [];
if ($_SESSION["role"] === "Admin") {
    $requests = $pdo->query("SELECT r.id,u.full_name,b.title,r.requested_at FROM issue_requests r JOIN users u ON u.id=r.member_id JOIN books b ON b.id=r.book_id WHERE r.status='Pending' ORDER BY r.id DESC")->fetchAll();
    $returnRequests = $pdo->query("SELECT r.id,r.issue_id,u.full_name,b.title,r.requested_at FROM return_requests r JOIN users u ON u.id=r.member_id JOIN issue_returns ir ON ir.id=r.issue_id JOIN books b ON b.id=ir.book_id WHERE r.status='Pending' ORDER BY r.id DESC")->fetchAll();
    $active = $pdo->query("SELECT ir.id,u.full_name,b.title,ir.issue_date,ir.return_date FROM issue_returns ir JOIN users u ON u.id=ir.member_id JOIN books b ON b.id=ir.book_id WHERE ir.status='Issued' ORDER BY ir.id DESC")->fetchAll();
} else {
    $stmt = $pdo->prepare("SELECT r.id,b.title,r.requested_at,r.status FROM issue_requests r JOIN books b ON b.id=r.book_id WHERE r.member_id=? ORDER BY r.id DESC");
    $stmt->execute([$_SESSION["user_id"]]);
    $requests = $stmt->fetchAll();
    $stmt = $pdo->prepare("SELECT r.issue_id,b.title,r.requested_at,r.status FROM return_requests r JOIN issue_returns ir ON ir.id=r.issue_id JOIN books b ON b.id=ir.book_id WHERE r.member_id=? ORDER BY r.id DESC");
    $stmt->execute([$_SESSION["user_id"]]);
    $returnRequests = $stmt->fetchAll();
    $stmt = $pdo->prepare("SELECT ir.id,b.title,ir.issue_date,ir.return_date,ir.status FROM issue_returns ir JOIN books b ON b.id=ir.book_id WHERE ir.member_id=? ORDER BY ir.id DESC");
    $stmt->execute([$_SESSION["user_id"]]);
    $active = $stmt->fetchAll();
}
require "partials/header.php";
require "partials/sidebar.php";
?>
<h5>Issue / Return Books</h5>
<?php if ($message = flash("success")): ?><div class="alert alert-success"><?=e($message)?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?=e($error)?></div><?php endif; ?>
<?php if ($_SESSION["role"] !== "Admin"): ?>
<div class="card p-3 mt-3"><h6>Request a Book</h6><form method="post" class="row g-3"><input type="hidden" name="action" value="request"><div class="col-md-8"><label>Select Book</label><select class="form-select" name="book_id" required><?php foreach ($books as $book): ?><option value="<?=$book["id"]?>"><?=e($book["title"])?> (<?=$book["available_copies"]?> available)</option><?php endforeach; ?></select></div><div class="col-md-4 d-flex align-items-end"><button class="btn btn-primary w-100">Send Issue Request</button></div></form></div>
<div class="card p-3 mt-3"><h6>My Requests</h6><div class="table-responsive"><table class="table"><thead><tr><th>#</th><th>Book</th><th>Requested</th><th>Status</th></tr></thead><tbody><?php foreach ($requests as $i => $request): ?><tr><td><?=$i + 1?></td><td><?=e($request["title"])?></td><td><?=e($request["requested_at"])?></td><td><?=e($request["status"])?></td></tr><?php endforeach; ?></tbody></table></div></div>
<div class="card p-3 mt-3"><h6>My Return Requests</h6><div class="table-responsive"><table class="table"><thead><tr><th>#</th><th>Book</th><th>Requested</th><th>Status</th></tr></thead><tbody><?php foreach ($returnRequests as $i => $request): ?><tr><td><?=$i + 1?></td><td><?=e($request["title"])?></td><td><?=e($request["requested_at"])?></td><td><?=e($request["status"])?></td></tr><?php endforeach; ?></tbody></table></div></div>
<?php else: ?>
<div class="card p-3 mt-3"><h6>Pending Issue Requests</h6><div class="table-responsive"><table class="table"><thead><tr><th>Member</th><th>Book</th><th>Requested</th><th>Action</th></tr></thead><tbody><?php foreach ($requests as $request): ?><tr><td><?=e($request["full_name"])?></td><td><?=e($request["title"])?></td><td><?=e($request["requested_at"])?></td><td><form method="post" class="d-inline"><input type="hidden" name="action" value="approve"><input type="hidden" name="request_id" value="<?=$request["id"]?>"><button class="btn btn-sm btn-success">Approve</button></form> <form method="post" class="d-inline"><input type="hidden" name="action" value="reject"><input type="hidden" name="request_id" value="<?=$request["id"]?>"><button class="btn btn-sm btn-outline-danger">Reject</button></form></td></tr><?php endforeach; ?></tbody></table></div></div>
<div class="card p-3 mt-3"><h6>Pending Return Requests</h6><div class="table-responsive"><table class="table"><thead><tr><th>Member</th><th>Book</th><th>Requested</th><th>Action</th></tr></thead><tbody><?php foreach ($returnRequests as $request): ?><tr><td><?=e($request["full_name"])?></td><td><?=e($request["title"])?></td><td><?=e($request["requested_at"])?></td><td><form method="post" class="d-inline"><input type="hidden" name="action" value="approve_return"><input type="hidden" name="return_request_id" value="<?=$request["id"]?>"><button class="btn btn-sm btn-success">Approve Return</button></form> <form method="post" class="d-inline"><input type="hidden" name="action" value="reject_return"><input type="hidden" name="return_request_id" value="<?=$request["id"]?>"><button class="btn btn-sm btn-outline-danger">Reject</button></form></td></tr><?php endforeach; ?></tbody></table></div></div>
<div class="card p-3 mt-3"><ul class="nav nav-tabs"><li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#issue">Issue Book</button></li><li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#return">Return Book</button></li></ul><div class="tab-content pt-3"><div class="tab-pane fade show active" id="issue"><form method="post"><input type="hidden" name="action" value="issue"><div class="row g-3"><div class="col-md-6"><label>Select Member</label><select class="form-select" name="member_id" required><?php foreach ($members as $member): ?><option value="<?=$member["id"]?>"><?=e($member["full_name"])?> (<?=e($member["member_code"])?>)</option><?php endforeach; ?></select></div><div class="col-md-6"><label>Select Book</label><select class="form-select" name="book_id" required><?php foreach ($books as $book): ?><option value="<?=$book["id"]?>"><?=e($book["title"])?> (<?=$book["available_copies"]?> available)</option><?php endforeach; ?></select></div><div class="col-md-6"><label>Issue Date</label><input class="form-control" type="date" name="issue_date" value="<?=date('Y-m-d')?>" required></div><div class="col-md-6"><label>Return Date</label><input class="form-control" type="date" name="return_date" value="<?=date('Y-m-d', strtotime('+14 days'))?>" required></div></div><button class="btn btn-primary mt-3">Issue Book</button></form></div><div class="tab-pane fade" id="return"><form method="post"><input type="hidden" name="action" value="return"><label>Issued Book</label><select class="form-select" name="issue_id" required><?php foreach ($active as $item): ?><option value="<?=$item["id"]?>"><?=e($item["full_name"])?> - <?=e($item["title"])?> (due <?=$item["return_date"]?>)</option><?php endforeach; ?></select><button class="btn btn-primary mt-3">Return Book</button></form></div></div></div>
<?php endif; ?>
<div class="card p-3 mt-3 table-responsive"><table class="table"><thead><tr><th>#</th><th><?= $_SESSION["role"] === "Admin" ? "Member" : "Book" ?></th><th>Book</th><th>Issue Date</th><th>Return Date</th><th>Status</th><?php if ($_SESSION["role"] !== "Admin"): ?><th>Action</th><?php endif; ?></tr></thead><tbody><?php foreach ($active as $i => $item): ?><tr><td><?=$i + 1?></td><td><?=e($item["full_name"] ?? $item["title"])?></td><td><?=e($item["title"])?></td><td><?=$item["issue_date"]?></td><td><?=$item["return_date"]?></td><td><span class="badge-soft"><?=e($item["status"] ?? "Issued")?></span></td><?php if ($_SESSION["role"] !== "Admin"): ?><td><form method="post"><input type="hidden" name="action" value="return_request"><input type="hidden" name="issue_id" value="<?=$item["id"]?>"><button class="btn btn-sm btn-outline-primary">Request Return</button></form></td><?php endif; ?></tr><?php endforeach; ?></tbody></table></div>
<?php require "partials/footer.php"; ?>
