<?php
require_once "auth.php";
requireAdmin();
$pageTitle = "Members Management";
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST["action"] ?? "") === "delete") {
    $id = (int)($_POST["member_id"] ?? 0);
    if ($id != $_SESSION["user_id"]) {
        $s = $pdo->prepare("DELETE FROM users WHERE id=? AND role<>'Admin'");
        $s->execute([$id]);
    }header("Location:members.php");
    exit;
}
$members = $pdo->query("SELECT * FROM users WHERE role<>'Admin' ORDER BY id DESC")->fetchAll();
require "partials/header.php";
require "partials/sidebar.php";?>
<div class="d-flex justify-content-between">
    <h5>Members Management</h5>
    <a class="btn btn-primary btn-sm" href="member_form.php">+ Add Member</a>
</div>
<div class="card p-3 mt-3 table-responsive">
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Role</th>
                <th>Member ID</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($members as $i => $m):?>
                <tr>
                    <td><?=$i + 1?></td>
                    <td><?=e($m["full_name"])?></td>
                    <td><?=e($m["email"])?></td>
                    <td><?=e($m["mobile"])?></td>
                    <td><?=$m["role"]?></td>
                    <td><?=$m["member_code"]?></td>
                    <td><a class="btn btn-sm btn-outline-primary" href="member_form.php?id=<?=$m["id"]?>">✎</a> 
                    <form method="post" class="d-inline">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="member_id" value="<?=$m["id"]?>">
                        <button type="submit" data-confirm="Delete member?" class="btn btn-sm btn-outline-danger">🗑</button>
                    </form>
                </td>
            </tr><?php endforeach;?></tbody>
        </table>
    </div>
    <?php require "partials/footer.php"; ?>