</main></div>
<button class="chatbot-toggle" type="button" aria-label="Open Library Assistant">🤖</button>
<section class="chatbot-panel" hidden aria-label="Library Assistant">
  <div class="chatbot-header"><div><strong>Library Assistant</strong><div class="small opacity-75">Books • Shopping • Issue • PDFs</div></div><div class="d-flex gap-1 align-items-center"><select class="chatbot-language" title="Language"><option value="auto">Auto</option><option value="en">English</option><option value="hi">हिन्दी</option><option value="es">Español</option><option value="fr">Français</option><option value="de">Deutsch</option><option value="bn">বাংলা</option><option value="mr">मराठी</option></select><button type="button" class="chatbot-clear" title="Clear chat">↻</button><button type="button" class="chatbot-close" aria-label="Close assistant">&times;</button></div></div>
  <div class="chatbot-messages"><div class="chatbot-message bot">Hello! 👋 Ask me to find a book, check availability, shop, download an authorized PDF, or explain issue/return.</div></div>
  <div class="chatbot-quick"><button type="button" data-chat="Show available books">📚 Books</button><button type="button" data-chat="Show my books">📖 My Books</button><button type="button" data-chat="Open shopping cart">🛒 Cart</button><button type="button" data-chat="Help me">❓ Help</button></div>
  <form class="chatbot-form"><input class="chatbot-input" type="text" placeholder="Ask anything about the library..." autocomplete="off" required><button type="submit">Send</button></form>
</section>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
document.querySelectorAll('[data-confirm]').forEach(x=>x.addEventListener('click',e=>{if(!confirm(x.dataset.confirm))e.preventDefault();}));
const toggle=document.querySelector('.chatbot-toggle'),panel=document.querySelector('.chatbot-panel'),close=document.querySelector('.chatbot-close'),clear=document.querySelector('.chatbot-clear'),form=document.querySelector('.chatbot-form'),input=document.querySelector('.chatbot-input'),messages=document.querySelector('.chatbot-messages'),lang=document.querySelector('.chatbot-language');
if(!toggle)return;
try{lang.value=localStorage.getItem('library_chat_lang')||'auto';}catch(e){}
lang.addEventListener('change',()=>{try{localStorage.setItem('library_chat_lang',lang.value)}catch(e){}});
toggle.addEventListener('click',()=>{panel.hidden=!panel.hidden;if(!panel.hidden)input.focus();});close.addEventListener('click',()=>panel.hidden=true);
clear.addEventListener('click',()=>{messages.innerHTML='<div class="chatbot-message bot">Chat cleared. How can I help?</div>';});
document.querySelectorAll('[data-chat]').forEach(b=>b.addEventListener('click',()=>{input.value=b.dataset.chat;form.requestSubmit();}));
async function send(message){
 messages.insertAdjacentHTML('beforeend','<div class="chatbot-message user">'+esc(message)+'</div>');messages.scrollTop=messages.scrollHeight;input.value='';
 const typing=document.createElement('div');typing.className='chatbot-message bot chatbot-typing';typing.textContent='•••';messages.appendChild(typing);messages.scrollTop=messages.scrollHeight;
 const data=new FormData();data.append('message',message);data.append('language',lang.value);
 try{const response=await fetch('chatbot.php',{method:'POST',body:data,headers:{'X-Requested-With':'XMLHttpRequest'}});const result=await response.json();typing.remove();messages.insertAdjacentHTML('beforeend','<div class="chatbot-message bot">'+(result.reply||'No response.')+'</div>');}
 catch(e){typing.remove();messages.insertAdjacentHTML('beforeend','<div class="chatbot-message bot">Assistant is temporarily unavailable. Please try again.</div>');}
 messages.scrollTop=messages.scrollHeight;
}
form.addEventListener('submit',e=>{e.preventDefault();const m=input.value.trim();if(m)send(m);});
})();
</script>
</body></html>
