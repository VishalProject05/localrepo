<?php
require_once __DIR__ . "/../auth.php";
$notificationCount = 0;
if ($_SESSION["role"] === "Admin") {
    $notificationCount = (int)$pdo->query("SELECT COUNT(*) FROM issue_requests WHERE status='Pending'")->fetchColumn();
    $notificationCount += (int)$pdo->query("SELECT COUNT(*) FROM return_requests WHERE status='Pending'")->fetchColumn();
} else {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM issue_requests WHERE member_id=? AND status='Pending'");
    $stmt->execute([$_SESSION["user_id"]]);
    $notificationCount = (int)$stmt->fetchColumn();
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM return_requests WHERE member_id=? AND status='Pending'");
    $stmt->execute([$_SESSION["user_id"]]);
    $notificationCount += (int)$stmt->fetchColumn();
}

$headerUser = null;
$hs = $pdo->prepare("SELECT full_name, profile_pic FROM users WHERE id=?");
$hs->execute([$_SESSION["user_id"]]);
$headerUser = $hs->fetch() ?: [];
$cartCount = 0;
foreach (($_SESSION["cart"] ?? []) as $q) { $cartCount += (int)$q; }
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($pageTitle ?? "Online Library") ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="topbar">
  <div><span class="brand-icon">📖</span><span class="brand">Online Library<small>Management System</small></span></div>
  <div class="links">
    <a class="navbar-link" href="<?= $_SESSION['role'] === 'Admin' ? 'admin_dashboard.php' : 'member_dashboard.php' ?>">Read</a>
    <a class="navbar-link" href="search.php">Learn</a>
    <a class="navbar-link" href="profile.php">Grow</a>
    <div class="dropdown d-inline-block ms-4">
      <button class="btn btn-link text-decoration-none p-0 position-relative" type="button" data-bs-toggle="dropdown" aria-expanded="false" title="Notifications">🔔
        <?php if ($notificationCount > 0): ?><span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"><?= $notificationCount ?></span><?php endif; ?>
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><h6 class="dropdown-header">Notifications</h6></li>
        <?php if ($notificationCount > 0): ?><li><a class="dropdown-item" href="issue_return.php">You have <?= $notificationCount ?> pending request<?= $notificationCount === 1 ? "" : "s" ?>.</a></li><?php else: ?><li><span class="dropdown-item-text text-muted">No new notifications</span></li><?php endif; ?>
      </ul>
    </div>
    <a href="cart.php" class="navbar-link position-relative ms-3" title="Shopping Cart">🛒<?php if($cartCount>0): ?><span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-primary"><?=$cartCount?></span><?php endif; ?></a>
    <a href="profile.php" class="user-menu ms-3" title="Profile">
      <?php if (!empty($headerUser["profile_pic"]) && is_file(__DIR__ . "/../" . $headerUser["profile_pic"])): ?>
        <img src="<?=e($headerUser["profile_pic"])?>" alt="Profile" class="header-avatar">
      <?php else: ?><span class="header-avatar fallback">👤</span><?php endif; ?>
      <span><?=e($headerUser["full_name"] ?? $_SESSION["full_name"])?> ▾</span>
    </a>
  </div>
</div>
<div class="layout">