Place only PDF files that you own or are authorized to distribute in this folder.

To attach a PDF to a book:
1. Login as Admin.
2. Open Books > Edit for the book.
3. Upload the legal PDF in the Legal PDF field.
4. Save the book.

Users can download an attached PDF from Book Details. If no authorized file is attached, the page explains why it is unavailable.
