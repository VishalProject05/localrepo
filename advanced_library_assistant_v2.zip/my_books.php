<?php
require_once "auth.php";
requireLogin();
$pageTitle = "My Books";
$st = $pdo->prepare("SELECT ir.*,b.title,b.author FROM issue_returns ir JOIN books b ON b.id=ir.book_id WHERE ir.member_id=? ORDER BY ir.id DESC");
$st->execute([$_SESSION["user_id"]]);
$rows = $st->fetchAll();
require "partials/header.php";
require "partials/sidebar.php";?>
<h5>My Books</h5><div class="card p-3 mt-3 table-responsive"><table class="table"><thead><tr><th>#</th><th>Book</th><th>Author</th><th>Issue Date</th><th>Due Date</th><th>Status</th></tr></thead><tbody><?php foreach ($rows as $i => $r):?><tr><td><?=$i + 1?></td><td><?=e($r["title"])?></td><td><?=e($r["author"])?></td><td><?=$r["issue_date"]?></td><td><?=$r["return_date"]?></td><td><span class="badge-soft"><?=$r["status"]?></span></td></tr><?php endforeach;?></tbody></table></div><?php require "partials/footer.php"; ?>