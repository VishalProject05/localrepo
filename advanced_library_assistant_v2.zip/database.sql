CREATE DATABASE IF NOT EXISTS online_library CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE online_library;
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS return_requests;
DROP TABLE IF EXISTS issue_requests;
DROP TABLE IF EXISTS issue_returns;
DROP TABLE IF EXISTS books;
DROP TABLE IF EXISTS members;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    mobile VARCHAR(20) DEFAULT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('Admin','Student','Staff') NOT NULL DEFAULT 'Student',
    member_code VARCHAR(30) UNIQUE,
    profile_pic VARCHAR(255) DEFAULT NULL,
    preferred_language VARCHAR(10) NOT NULL DEFAULT 'auto',
    created_at DATE NOT NULL
);

CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    author VARCHAR(120) NOT NULL,
    category VARCHAR(80) NOT NULL,
    isbn VARCHAR(20) DEFAULT NULL,
    publisher VARCHAR(150) DEFAULT NULL,
    total_copies INT NOT NULL DEFAULT 1,
    available_copies INT NOT NULL DEFAULT 1,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    currency VARCHAR(8) NOT NULL DEFAULT 'INR',
    purchase_url VARCHAR(500) DEFAULT NULL,
    language VARCHAR(80) NOT NULL DEFAULT 'English',
    description TEXT,
    cover_image VARCHAR(255) DEFAULT NULL,
    digital_file VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE issue_returns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT NOT NULL,
    book_id INT NOT NULL,
    issue_date DATE NOT NULL,
    return_date DATE NOT NULL,
    actual_return_date DATE DEFAULT NULL,
    fine DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    remarks VARCHAR(255) DEFAULT NULL,
    status ENUM('Issued','Returned','Overdue') NOT NULL DEFAULT 'Issued',
    FOREIGN KEY (member_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
);

CREATE TABLE issue_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT NOT NULL,
    book_id INT NOT NULL,
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
    FOREIGN KEY (member_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
);

CREATE TABLE return_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    issue_id INT NOT NULL,
    member_id INT NOT NULL,
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
    FOREIGN KEY (issue_id) REFERENCES issue_returns(id) ON DELETE CASCADE,
    FOREIGN KEY (member_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    currency VARCHAR(8) NOT NULL DEFAULT 'INR',
    payment_method ENUM('Cash on Delivery','UPI / Bank Transfer','External Store') NOT NULL DEFAULT 'Cash on Delivery',
    payment_status ENUM('Pending','Paid','Cancelled') NOT NULL DEFAULT 'Pending',
    order_status ENUM('Placed','Processing','Shipped','Completed','Cancelled') NOT NULL DEFAULT 'Placed',
    shipping_address TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    book_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    unit_price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
);

INSERT INTO users (full_name,email,mobile,password,role,member_code,preferred_language,created_at) VALUES
('Admin','vishalkushwaha7451@gmail.com','9000000000', '$2y$12$KQzV1H15xldGFlaYu/pvSuUK22JnlBY.hBTZKakX4OS0s1byZ0HEC', 'Admin','ADM001','auto','2026-09-01'),
('Rahul Kumar','rahul@gmail.com','9876543210', '$2y$10$92IXUNZ8QyK6XQ9b5k0V8O7ZgQ6u5b1m0mM6Q6k0H9Z8m5e7x8p9S', 'Student','M001','auto','2025-06-01'),
('Priya Singh','priya@gmail.com','8765422109', '$2y$10$92IXUNZ8QyK6XQ9b5k0V8O7ZgQ6u5b1m0mM6Q6k0H9Z8m5e7x8p9S', 'Student','M002','auto','2025-06-02'),
('Amit Yadav','amit@gmail.com','7654321098', '$2y$10$92IXUNZ8QyK6XQ9b5k0V8O7ZgQ6u5b1m0mM6Q6k0H9Z8m5e7x8p9S', 'Student','M003','auto','2025-06-03'),
('Sneha Gupta','sneha@gmail.com','6543210987', '$2y$10$92IXUNZ8QyK6XQ9b5k0V8O7ZgQ6u5b1m0mM6Q6k0H9Z8m5e7x8p9S', 'Student','M004','auto','2025-06-04'),
('Rohan Sharma','rohan@gmail.com','5432108765', '$2y$10$92IXUNZ8QyK6XQ9b5k0V8O7ZgQ6u5b1m0mM6Q6k0Z8m5e7x8p9S', 'Student','M005','auto','2025-06-05');

INSERT INTO books (title,author,category,total_copies,available_copies,price,currency,language,description,cover_image) VALUES
('C Programming','Dennis Ritchie','Programming',10,8,499,'INR','English','A classic introduction to C programming and computer programming fundamentals.','c-programming.svg'),
('Python Basics','Guido van Rossum','Programming',15,12,449,'INR','English','Beginner friendly Python programming concepts and examples.','python-basics.svg'),
('Data Structures','R. G. Dromey','Computer Science',10,7,599,'INR','English','Core data structures, algorithms and problem solving.','data-structures.svg'),
('Java Programming','Herbert Schildt','Programming',12,10,699,'INR','English','Java programming concepts from fundamentals to advanced topics.','java-programming.svg'),
('Web Development','Jon Duckett','Web',8,6,799,'INR','English','HTML, CSS and JavaScript concepts for modern web development.','web-development.svg');

INSERT INTO books (title,author,category,total_copies,available_copies,price,currency,language,description,cover_image)
SELECT CONCAT(topic_name,' - ',edition_name), 'Library Academic Series', 'Computer Science', 5, 5, 399,'INR','English',
       CONCAT('Computer Science reference book covering ',LOWER(topic_name),' for ',LOWER(edition_name),'.'), 'computer-science.svg'
FROM
 (SELECT 'Algorithms' topic_name UNION ALL SELECT 'Artificial Intelligence' UNION ALL SELECT 'Computer Networks' UNION ALL SELECT 'Operating Systems' UNION ALL SELECT 'Database Systems' UNION ALL SELECT 'Software Engineering' UNION ALL SELECT 'Computer Architecture' UNION ALL SELECT 'Compiler Design' UNION ALL SELECT 'Cyber Security' UNION ALL SELECT 'Cloud Computing' UNION ALL SELECT 'Machine Learning' UNION ALL SELECT 'Data Mining' UNION ALL SELECT 'Distributed Systems' UNION ALL SELECT 'Computer Graphics' UNION ALL SELECT 'Theory of Computation' UNION ALL SELECT 'Discrete Mathematics' UNION ALL SELECT 'Human Computer Interaction' UNION ALL SELECT 'Information Retrieval' UNION ALL SELECT 'Natural Language Processing' UNION ALL SELECT 'Parallel Computing' UNION ALL SELECT 'Internet of Things' UNION ALL SELECT 'Quantum Computing') topics
CROSS JOIN
 (SELECT 'Foundations' edition_name UNION ALL SELECT 'Core Concepts' UNION ALL SELECT 'Practical Guide' UNION ALL SELECT 'Algorithms and Techniques' UNION ALL SELECT 'Design Patterns' UNION ALL SELECT 'Programming Workshop' UNION ALL SELECT 'Advanced Methods' UNION ALL SELECT 'Laboratory Manual' UNION ALL SELECT 'Research Perspectives' UNION ALL SELECT 'Exam Preparation') editions;

-- Osho catalog: metadata and official purchase/eBook links only. No copyrighted PDFs are bundled.
INSERT INTO books (title,author,category,total_copies,available_copies,price,currency,purchase_url,language,description,cover_image) VALUES
('The Book of Secrets','Osho','Osho / Meditation',0,0,890,'INR','https://books-india.osho.com/en/cartquickpro/catalog_product/view/id/1140','English','A comprehensive guide to 112 awareness techniques. Official OSHO India purchase link.','osho.svg'),
('Awareness: The Key to Living in Balance','Osho','Osho / Awareness',0,0,0,'INR','https://shop.osho.com/en/awareness-the-key-to-living-in-balance','English','Official OSHO eBook/book catalog entry.','osho.svg'),
('Creativity: Unleashing the Forces Within','Osho','Osho / Creativity',0,0,0,'INR','https://shop.osho.com/en/osho-ebooks/creativity','English, French, German, Japanese, Portuguese, Russian','Official OSHO catalog entry; availability varies by format and region.','osho.svg'),
('Courage: The Joy of Living Dangerously','Osho','Osho / Courage',0,0,0,'INR','https://shop.osho.com/en/international-osho-books/compilations/courage-the-joy-of-living-dangerously','English','Official OSHO catalog entry.','osho.svg'),
('Freedom','Osho','Osho / Freedom',0,0,0,'INR','https://shop.osho.com/en/freedom','English','Official OSHO eBook/book catalog entry.','osho.svg'),
('Meditation: The Art of Ecstasy','Osho','Osho / Meditation',0,0,4.95,'USD','https://shop.osho.com/en/osho-ebooks/osho-talks/meditation-reality','English','Official OSHO eBook catalog entry.','osho.svg'),
('Meditation for Busy People','Osho','Osho / Meditation',0,0,4.95,'USD','https://shop.osho.com/en/osho-ebooks/meditation-buddha-compilations','English','Official OSHO eBook catalog entry.','osho.svg'),
('What Is Meditation?','Osho','Osho / Meditation',0,0,0,'INR','https://shop.osho.com/en/osho-ebooks/meditation-buddha-compilations','English','Official OSHO eBook catalog entry.','osho.svg'),
('The Perfect Way','Osho','Osho / Meditation',0,0,4.95,'USD','https://shop.osho.com/en/osho-ebooks/meditation-reality','English','Official OSHO eBook catalog entry.','osho.svg'),
('Beyond Psychology','Osho','Osho / Mind',0,0,4.95,'USD','https://shop.osho.com/en/osho-ebooks/osho-talks/mind-meditation','English','Official OSHO eBook catalog entry.','osho.svg'),
('From Bondage to Freedom','Osho','Osho / Freedom',0,0,4.95,'USD','https://shop.osho.com/en/osho-ebooks/trust-freedom','English','Official OSHO eBook catalog entry.','osho.svg'),
('The Path of the Mystic','Osho','Osho / Freedom',0,0,4.95,'USD','https://shop.osho.com/en/osho-ebooks/trust-freedom','English','Official OSHO eBook catalog entry.','osho.svg'),
('A Course in Meditation','Osho','Osho / Meditation',0,0,0,'INR','https://shop.osho.com/en/osho-ebooks/meditation-therapy','English','Official OSHO catalog entry.','osho.svg'),
('Aspects of Meditation Book 1','Osho','Osho / Meditation',0,0,0,'INR','https://shop.osho.com/en/osho-ebooks/aspects-of-meditation-book-1-eb','English','Official OSHO catalog entry.','osho.svg'),
('When the Shoe Fits','Osho','Osho / Zen',0,0,0,'INR','https://shop.osho.com/en/international-osho-books/osho-talks/tao-buddha','English','Official OSHO catalog entry.','osho.svg');

INSERT INTO issue_returns (member_id,book_id,issue_date,return_date,status) VALUES
(2,1,'2025-09-01','2025-09-15','Issued'),
(3,3,'2025-09-02','2025-09-16','Issued'),
(4,2,'2025-09-03','2025-09-17','Issued'),
(5,4,'2025-09-04','2025-09-18','Issued'),
(6,5,'2025-09-05','2025-09-19','Issued');
SET FOREIGN_KEY_CHECKS = 1;
