<?php
require_once "auth.php";
requireAdmin();
$pageTitle = "Reports";
$from = $_GET["from"] ?? date("Y-m-01");
$to = $_GET["to"] ?? date("Y-m-d");
$st = $pdo->prepare("SELECT COUNT(*) FROM issue_returns WHERE issue_date BETWEEN ? AND ?");
$st->execute([$from,$to]);
$issued = (int)$st->fetchColumn();
$st = $pdo->prepare("SELECT COUNT(*) FROM issue_returns WHERE status='Returned' AND actual_return_date BETWEEN ? AND ?");
$st->execute([$from,$to]);
$returned = (int)$st->fetchColumn();
$members = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role<>'Admin'")->fetchColumn();
$overdue = (int)$pdo->query("SELECT COUNT(*) FROM issue_returns WHERE status='Issued' AND return_date<CURDATE()")->fetchColumn();
$fineTotal = (float)$pdo->query("SELECT COALESCE(SUM(fine),0) FROM issue_returns")->fetchColumn();
$rows = $pdo->query("SELECT ir.*,b.title,u.full_name FROM issue_returns ir JOIN books b ON b.id=ir.book_id JOIN users u ON u.id=ir.member_id ORDER BY ir.id DESC LIMIT 20")->fetchAll();
require "partials/header.php";
require "partials/sidebar.php";?><h5>Reports</h5><form class="card p-3 mt-3"><div class="row g-2 align-items-end"><div class="col-md-4"><label>From</label><input class="form-control" type="date" name="from" value="<?=$from?>"></div><div class="col-md-4"><label>To</label><input class="form-control" type="date" name="to" value="<?=$to?>"></div><div class="col-md-2"><button class="btn btn-primary w-100">Generate</button></div></div></form>
<div class="row g-3 mt-2"><div class="col-md-3"><div class="card p-3"><small>📗 Books Issued</small><h3><?=$issued?></h3></div></div><div class="col-md-3"><div class="card p-3"><small>↩ Books Returned</small><h3><?=$returned?></h3></div></div><div class="col-md-3"><div class="card p-3"><small>👥 Total Members</small><h3><?=$members?></h3></div></div><div class="col-md-3"><div class="card p-3"><small>▣ Overdue Books</small><h3><?=$overdue?></h3></div></div><div class="col-md-3"><div class="card p-3"><small>Fine Collected</small><h3>₹<?=number_format($fineTotal, 2)?></h3></div></div></div>
<div class="card p-3 mt-3 table-responsive"><h6>Issue/Return Report</h6><table class="table"><thead><tr><th>#</th><th>Book Name</th><th>Member Name</th><th>Issue Date</th><th>Due Date</th><th>Status</th><th>Fine</th></tr></thead><tbody><?php foreach ($rows as $i => $r):?><tr><td><?=$i + 1?></td><td><?=e($r["title"])?></td><td><?=e($r["full_name"])?></td><td><?=$r["issue_date"]?></td><td><?=$r["return_date"]?></td><td><?=$r["status"]?></td><td>₹<?=number_format((float)($r["fine"] ?? 0), 2)?></td></tr><?php endforeach;?></tbody></table></div><?php require "partials/footer.php"; ?>