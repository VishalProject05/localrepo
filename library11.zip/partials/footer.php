</main></div>
<button class="chatbot-toggle" type="button" aria-label="Open help assistant">AI</button>
<section class="chatbot-panel" hidden aria-label="Library help assistant">
	<div class="chatbot-header"><strong>Library Assistant</strong><button type="button" class="chatbot-close" aria-label="Close assistant">&times;</button></div>
	<div class="chatbot-messages"><div class="chatbot-message bot">Hello! Ask me about login, books, issue, return, password, or notifications.</div></div>
	<form class="chatbot-form"><input class="chatbot-input" type="text" placeholder="Type your question..." autocomplete="off" required><button type="submit">Send</button></form>
</section>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.querySelectorAll("[data-confirm]").forEach(x=>x.addEventListener("click",e=>{
 if(!confirm(x.dataset.confirm)){e.preventDefault();}
}));
const chatbotToggle = document.querySelector(".chatbot-toggle");
const chatbotPanel = document.querySelector(".chatbot-panel");
const chatbotClose = document.querySelector(".chatbot-close");
const chatbotForm = document.querySelector(".chatbot-form");
const chatbotInput = document.querySelector(".chatbot-input");
const chatbotMessages = document.querySelector(".chatbot-messages");
chatbotToggle.addEventListener("click",()=>{chatbotPanel.hidden=!chatbotPanel.hidden;if(!chatbotPanel.hidden)chatbotInput.focus();});
chatbotClose.addEventListener("click",()=>{chatbotPanel.hidden=true;});
chatbotForm.addEventListener("submit",async event=>{
 event.preventDefault();
 const message=chatbotInput.value.trim();
 if(!message)return;
 chatbotMessages.insertAdjacentHTML("beforeend",`<div class="chatbot-message user">${message.replace(/[&<>\"']/g,char=>({"&":"&amp;","<":"&lt;",">":"&gt;",'\"':"&quot;", "'":"&#039;"}[char]))}</div>`);
 chatbotInput.value="";
 chatbotMessages.scrollTop=chatbotMessages.scrollHeight;
 const data=new FormData();data.append("message",message);
 try { const response=await fetch("chatbot.php",{method:"POST",body:data});const result=await response.json();chatbotMessages.insertAdjacentHTML("beforeend",`<div class="chatbot-message bot">${result.reply}</div>`); }
 catch { chatbotMessages.insertAdjacentHTML("beforeend",'<div class="chatbot-message bot">Assistant is unavailable. Please try again.</div>'); }
 chatbotMessages.scrollTop=chatbotMessages.scrollHeight;
});
</script>
</body></html>