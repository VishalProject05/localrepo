<?php
require_once "auth.php";
requireLogin();
header("Content-Type: application/json; charset=UTF-8");

$question = trim($_POST["message"] ?? "");
if ($question === "") {
    echo json_encode(["reply" => "Please type your question."]);
    exit;
}

$text = strtolower($question);
$role = $_SESSION["role"];
if (str_contains($text, "password") || str_contains($text, "forgot") || str_contains($text, "भूल")) {
    $reply = "Password भूलने पर login page में Forgot password? खोलें, email और registered mobile डालकर नया password set करें.";
} elseif (str_contains($text, "issue") || str_contains($text, "request") || str_contains($text, "book मांग") || str_contains($text, "book lena")) {
    $reply = $role === "Admin"
        ? "Issue / Return Books खोलें। Pending Issue Requests में Approve करें, या Issue Book tab से member और book चुनकर issue करें."
        : "Issue / Return Books खोलें, book select करके Send Issue Request दबाएँ। Admin approve करने के बाद book आपके My Books में दिखेगी.";
} elseif (str_contains($text, "return") || str_contains($text, "वापस")) {
    $reply = $role === "Admin"
        ? "Pending Return Requests में Approve Return दबाएँ। इससे book Returned होगी और available copies बढ़ेंगी."
        : "My issued book के सामने Request Return दबाएँ। Admin approve करने के बाद return complete होगा.";
} elseif (str_contains($text, "cover") || str_contains($text, "photo") || str_contains($text, "image")) {
    $reply = $role === "Admin"
        ? "Add Book page पर JPG, PNG या WEBP cover upload करना जरूरी है."
        : "Book cover Search Books और Book Details page पर दिखाई देता है.";
} elseif (str_contains($text, "notification") || str_contains($text, "bell")) {
    $reply = "Top bar के bell icon पर click करें। वहाँ pending issue या return requests दिखाई जाएंगी.";
} elseif (str_contains($text, "count") || str_contains($text, "copies") || str_contains($text, "संख्या")) {
    $reply = "Book issue होने पर available copies 1 कम होती हैं। Return approve होने पर available copies 1 बढ़ती हैं.";
} elseif (str_contains($text, "login") || str_contains($text, "लॉगिन")) {
    $reply = "Login page पर registered email और password डालें। Admin और user अपने अलग accounts से login करते हैं.";
} elseif (str_contains($text, "help") || str_contains($text, "problem") || str_contains($text, "error")) {
    $reply = "मैं login, password reset, book issue, return request, notification और cover upload में मदद कर सकता हूँ. अपना सवाल थोड़ा detail में लिखें.";
} else {
    $reply = "मैं इस सवाल को पूरी तरह समझ नहीं पाया। आप login, password, issue book, return book, cover, notification या copies के बारे में पूछ सकते हैं.";
}

echo json_encode(["reply" => $reply], JSON_UNESCAPED_UNICODE);
