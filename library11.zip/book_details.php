<?php
require_once "auth.php";
requireLogin();
$id = (int)($_GET["id"] ?? 0);
$s = $pdo->prepare("SELECT * FROM books WHERE id=?");
$s->execute([$id]);
$b = $s->fetch();
if (!$b) {
    http_response_code(404);
    die("Book not found");
}
$pageTitle = "Book Details";
require "partials/header.php";
require "partials/sidebar.php"; ?>
<h5>Book Details</h5><div class="card p-4 mt-3"><div class="row"><div class="col-md-3"><?php if (!empty($b["cover_image"])): ?><img class="img-fluid rounded" src="assets/covers/<?=e($b["cover_image"])?>" alt="Book cover"><?php else: ?><div class="book-cover"><?=e($b["title"])?></div><?php endif; ?></div><div class="col-md-9"><h4><?=e($b["title"])?></h4><p><b>Author:</b> <?=e($b["author"])?></p><p><b>Category:</b> <?=e($b["category"])?></p><p><b>ISBN:</b> <?=e($b["isbn"] ?? "-")?></p><p><b>Publisher:</b> <?=e($b["publisher"] ?? "-")?></p><p><b>Total Copies:</b> <?=$b["total_copies"]?></p><p><b>Available Copies:</b> <?=$b["available_copies"]?></p><p><b>Description:</b><br><?=nl2br(e($b["description"]))?></p><div class="mt-3"><?php if (!empty($b["digital_file"]) && is_file(__DIR__ . "/digital_books/" . basename($b["digital_file"]))): ?><a class="btn btn-success" href="download.php?id=<?=$b["id"]?>">Download PDF</a><?php else: ?><p class="text-muted">PDF unavailable: an authorized digital copy has not been added yet.</p><?php endif; ?></div><?php if ($_SESSION["role"] === "Admin"): ?><a class="btn btn-primary" href="book_form.php?id=<?=$b["id"]?>">Edit</a> <a data-confirm="Delete this book?" class="btn btn-danger" href="books.php?delete=<?=$b["id"]?>">Delete</a><?php endif;?></div></div></div>
<?php require "partials/footer.php"; ?>