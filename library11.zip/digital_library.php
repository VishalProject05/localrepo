<?php
require_once "auth.php";
requireAdmin();
$pageTitle = "Digital Library";
$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $bookId = (int)($_POST["book_id"] ?? 0);
    $pdf = $_FILES["digital_file"] ?? null;
    if (!$pdf || $pdf["error"] !== UPLOAD_ERR_OK) {
        $error = "Please select a PDF file.";
    } elseif (strtolower(pathinfo($pdf["name"], PATHINFO_EXTENSION)) !== "pdf" || $pdf["size"] > 20 * 1024 * 1024) {
        $error = "Only PDF files up to 20 MB are allowed.";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM books WHERE id=?");
        $stmt->execute([$bookId]);
        if (!$stmt->fetch()) {
            $error = "Book not found.";
        } else {
            $filename = bin2hex(random_bytes(16)) . ".pdf";
            if (move_uploaded_file($pdf["tmp_name"], __DIR__ . "/digital_books/" . $filename)) {
                $stmt = $pdo->prepare("UPDATE books SET digital_file=? WHERE id=?");
                $stmt->execute([$filename, $bookId]);
                $message = "PDF attached successfully.";
            } else {
                $error = "The PDF could not be saved.";
            }
        }
    }
}

$books = $pdo->query("SELECT id,title,author,category,digital_file FROM books ORDER BY category,title")->fetchAll();
require "partials/header.php";
require "partials/sidebar.php";
?>
<h5>Digital Library</h5>
<p class="text-muted small">Upload only PDFs that you own or are authorized to distribute.</p>
<?php if ($message): ?><div class="alert alert-success"><?=e($message)?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?=e($error)?></div><?php endif; ?>
<div class="card p-3 mt-3 table-responsive"><table class="table align-middle"><thead><tr><th>#</th><th>Book</th><th>Author</th><th>Category</th><th>PDF Status</th><th>Upload / Replace</th></tr></thead><tbody>
<?php foreach ($books as $i => $book): ?><tr><td><?=$i + 1?></td><td><a href="book_details.php?id=<?=$book["id"]?>"><?=e($book["title"])?></a></td><td><?=e($book["author"])?></td><td><?=e($book["category"])?></td><td><?php if (!empty($book["digital_file"]) && is_file(__DIR__ . "/digital_books/" . basename($book["digital_file"]))): ?><span class="badge-soft">PDF available</span><?php else: ?><span class="text-muted">Not uploaded</span><?php endif; ?></td><td><form method="post" enctype="multipart/form-data" class="d-flex gap-2"><input type="hidden" name="book_id" value="<?=$book["id"]?>"><input class="form-control form-control-sm" type="file" name="digital_file" accept="application/pdf" required><button class="btn btn-sm btn-primary">Upload</button></form></td></tr><?php endforeach; ?>
</tbody></table></div>
<?php require "partials/footer.php"; ?>
