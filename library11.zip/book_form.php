<?php
require_once "auth.php";
requireAdmin();
$id = (int)($_GET["id"] ?? 0);
$book = $id ? $pdo->query("SELECT * FROM books WHERE id=$id")->fetch() : null;
$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = trim($_POST["title"]);
    $author = trim($_POST["author"]);
    $category = trim($_POST["category"]);
    $isbn = trim($_POST["isbn"] ?? "");
    $publisher = trim($_POST["publisher"] ?? "");
    $total = (int)$_POST["total_copies"];
    $available = (int)$_POST["available_copies"];
    $desc = trim($_POST["description"]);
    $coverImage = $book["cover_image"] ?? null;
    $digitalFile = $book["digital_file"] ?? null;
    if (!$id && empty($_FILES["cover_image"]["name"])) {
        $error = "Book cover is required when adding a new book.";
    } elseif ($available > $total) {
        $error = "Available copies cannot be greater than total copies.";
    } elseif (!empty($_FILES["cover_image"]["name"])) {
        $file = $_FILES["cover_image"];
        $imageInfo = @getimagesize($file["tmp_name"]);
        $allowedTypes = ["image/jpeg" => "jpg", "image/png" => "png", "image/webp" => "webp"];
        if ($file["error"] !== UPLOAD_ERR_OK || !$imageInfo || !isset($allowedTypes[$imageInfo["mime"]])) {
            $error = "Please upload a JPG, PNG, or WEBP image.";
        } else {
            $coverImage = bin2hex(random_bytes(16)) . "." . $allowedTypes[$imageInfo["mime"]];
            move_uploaded_file($file["tmp_name"], __DIR__ . "/assets/covers/" . $coverImage);
        }
    }
    if (!$error && !empty($_FILES["digital_file"]["name"])) {
        $pdf = $_FILES["digital_file"];
        $extension = strtolower(pathinfo($pdf["name"], PATHINFO_EXTENSION));
        if ($pdf["error"] !== UPLOAD_ERR_OK || $extension !== "pdf" || $pdf["size"] > 20 * 1024 * 1024) {
            $error = "Please upload a PDF file up to 20 MB.";
        } else {
            $digitalFile = bin2hex(random_bytes(16)) . ".pdf";
            move_uploaded_file($pdf["tmp_name"], __DIR__ . "/digital_books/" . $digitalFile);
        }
    }
    if (!$error && $id) {
        $st = $pdo->prepare("UPDATE books SET title=?,author=?,category=?,isbn=?,publisher=?,total_copies=?,available_copies=?,description=?,cover_image=?,digital_file=? WHERE id=?");
        $st->execute([$title, $author, $category, $isbn, $publisher, $total, $available, $desc, $coverImage, $digitalFile, $id]);
    } elseif (!$error) {
        $st = $pdo->prepare("INSERT INTO books(title,author,category,isbn,publisher,total_copies,available_copies,description,cover_image,digital_file) VALUES(?,?,?,?,?,?,?,?,?,?)");
        $st->execute([$title, $author, $category, $isbn, $publisher, $total, $available, $desc, $coverImage, $digitalFile]);
    }
    if (!$error) {
        header("Location:books.php");
        exit;
    }
}
$pageTitle = $id ? "Edit Book" : "Add Book";
require "partials/header.php";
require "partials/sidebar.php"; ?>
<h5><?=$id ? "Edit Book" : "Add New Book"?></h5><div class="card p-4 mt-3">
<?php if ($error): ?><div class="alert alert-danger"><?=e($error)?></div><?php endif; ?><form method="post" enctype="multipart/form-data"><div class="row g-3"><div class="col-md-6"><label>Book Title</label><input class="form-control" name="title" required value="<?=e($book["title"] ?? $_POST["title"] ?? "")?>"></div><div class="col-md-6"><label>Author</label><input class="form-control" name="author" required value="<?=e($book["author"] ?? $_POST["author"] ?? "")?>"></div><div class="col-md-6"><label>Category</label><input class="form-control" name="category" required value="<?=e($book["category"] ?? $_POST["category"] ?? "")?>"></div><div class="col-md-3"><label>ISBN</label><input class="form-control" name="isbn" maxlength="20" value="<?=e($book["isbn"] ?? $_POST["isbn"] ?? "")?>"></div><div class="col-md-3"><label>Publisher</label><input class="form-control" name="publisher" value="<?=e($book["publisher"] ?? $_POST["publisher"] ?? "")?>"></div><div class="col-md-3"><label>Total Copies</label><input class="form-control" type="number" name="total_copies" min="1" required value="<?=e($book["total_copies"] ?? $_POST["total_copies"] ?? 1)?>"></div><div class="col-md-3"><label>Available Copies</label><input class="form-control" type="number" name="available_copies" min="0" required value="<?=e($book["available_copies"] ?? $_POST["available_copies"] ?? 1)?>"></div><div class="col-12"><label>Book Cover</label><input class="form-control" type="file" name="cover_image" accept="image/jpeg,image/png,image/webp" <?= !$id ? "required" : "" ?>><?php if (!empty($book["cover_image"])): ?><img class="mt-2" src="assets/covers/<?=e($book["cover_image"])?>" alt="Book cover" style="width:80px;height:110px;object-fit:cover"><?php endif; ?></div><div class="col-12"><label>Legal PDF (optional)</label><input class="form-control" type="file" name="digital_file" accept="application/pdf"><small class="text-muted">Only upload files you have permission to distribute. Maximum 20 MB.</small><?php if (!empty($book["digital_file"])): ?><div class="mt-2 text-success">PDF is attached.</div><?php endif; ?></div><div class="col-12"><label>Description</label><textarea class="form-control" name="description" rows="4"><?=e($book["description"] ?? $_POST["description"] ?? "")?></textarea></div></div><button class="btn btn-primary mt-3">Save Book</button> <a href="books.php" class="btn btn-light mt-3">Cancel</a></form></div><?php require "partials/footer.php"; ?>