<?php
require_once "auth.php";
requireLogin();
$pageTitle = "Search Books";
$q = trim($_GET["q"] ?? "");
if ($q) {
    $st = $pdo->prepare("SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR category LIKE ? OR isbn LIKE ? ORDER BY title");
    $like = "%$q%";
    $st->execute([$like, $like, $like, $like]);
    $books = $st->fetchAll();
} else {
    $books = $pdo->query("SELECT * FROM books ORDER BY title")->fetchAll();
}
require "partials/header.php";
require "partials/sidebar.php";?><h5>Search Books</h5><form class="d-flex gap-2 mt-3" method="get"><input class="form-control" name="q" placeholder="Search by title, author, category or ISBN..." value="<?=e($q)?>"><button class="btn btn-primary">Search</button></form><div class="card p-3 mt-3 table-responsive"><table class="table"><thead><tr><th>#</th><th>Cover</th><th>Book Title</th><th>ISBN</th><th>Author</th><th>Category</th><th>Status</th></tr></thead><tbody><?php foreach ($books as $i => $b):?><tr><td><?=$i + 1?></td><td><?php if (!empty($b["cover_image"])): ?><img src="assets/covers/<?=e($b["cover_image"])?>" alt="Book cover" style="width:45px;height:60px;object-fit:cover"><?php else: ?><span class="text-muted">No cover</span><?php endif; ?></td><td><a href="book_details.php?id=<?=$b["id"]?>"><?=e($b["title"])?></a></td><td><?=e($b["isbn"] ?? "-")?></td><td><?=e($b["author"])?></td><td><?=e($b["category"])?></td><td><?php if ($b["available_copies"] > 0):?><span class="badge-soft">Available</span><?php else:?><span class="badge bg-danger">Issued</span><?php endif;?></td></tr><?php endforeach;?></tbody></table></div><?php require "partials/footer.php"; ?>