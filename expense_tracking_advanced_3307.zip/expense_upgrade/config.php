<?php
$host='localhost'; $port=3307; $db='dets_db'; $user='root'; $pass='';
$conn=mysqli_connect($host,$user,$pass,$db,$port);
if(!$conn){ die('Database connection failed: '.mysqli_connect_error()); }
mysqli_set_charset($conn,'utf8mb4');
?>
