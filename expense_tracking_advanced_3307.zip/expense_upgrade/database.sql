CREATE DATABASE IF NOT EXISTS dets_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dets_db;
CREATE TABLE IF NOT EXISTS tb1user (
 userid INT AUTO_INCREMENT PRIMARY KEY, fullname VARCHAR(120) NOT NULL, email VARCHAR(150) NOT NULL UNIQUE,
 mobilenumber VARCHAR(20), password VARCHAR(255) NOT NULL, regdate DATETIME NOT NULL,
 profilepic VARCHAR(255) DEFAULT NULL, role ENUM('user','admin') NOT NULL DEFAULT 'user', status TINYINT(1) NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS tblexpence (
 expenseid INT AUTO_INCREMENT PRIMARY KEY, userid INT NOT NULL, expensedate DATE NOT NULL,
 category VARCHAR(80) NOT NULL, itemname VARCHAR(180) NOT NULL, expencecost DECIMAL(12,2) NOT NULL DEFAULT 0,
 notes VARCHAR(255) DEFAULT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(userid) REFERENCES tb1user(userid) ON DELETE CASCADE
);
INSERT INTO tb1user(fullname,email,mobilenumber,password,regdate,role) VALUES
('System Admin','admin@example.com','9999999999','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEaJ0a8q3zVq8wGqk5cH7x0zv7iK','2026-01-01 00:00:00','admin')
ON DUPLICATE KEY UPDATE role='admin';
