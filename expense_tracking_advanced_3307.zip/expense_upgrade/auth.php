<?php
session_start(); require_once __DIR__.'/config.php';
function require_login(){ if(empty($_SESSION['uid'])){ header('Location: login.php'); exit; } }
function require_admin(){ require_login(); if(($_SESSION['role']??'user')!=='admin'){ header('Location: dashboard.php'); exit; } }
function e($v){ return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
?>
