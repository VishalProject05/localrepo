<?php require_once 'auth.php';
if(isset($_SESSION['uid'])) header('Location: dashboard.php');
$msg='';
if(isset($_POST['btnreg'])){
 $email=trim($_POST['email']); $password=$_POST['password'];
 $st=mysqli_prepare($conn,'SELECT userid,fullname,password,role,status FROM tb1user WHERE email=? LIMIT 1'); mysqli_stmt_bind_param($st,'s',$email); mysqli_stmt_execute($st); $r=mysqli_stmt_get_result($st); $u=mysqli_fetch_assoc($r);
 if($u && $u['status'] && password_verify($password,$u['password'])){ $_SESSION['uid']=$u['userid']; $_SESSION['name']=$u['fullname']; $_SESSION['role']=$u['role']; header('Location: '.($u['role']==='admin'?'admin_dashboard.php':'dashboard.php')); exit; }
 $msg='Invalid email/password or inactive account.';
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login | ExpensePro</title><link href="bootstrap/css/bootstrap.min.css" rel="stylesheet"><link rel="stylesheet" href="style.css"></head><body class="auth-page"><div class="auth-card"><div class="brand"><i class="fa-solid fa-wallet"></i> ExpensePro</div><h3>Welcome back</h3><p class="muted">Sign in to manage your expenses</p><?php if($msg):?><div class="alert alert-danger"><?=e($msg)?></div><?php endif;?><form method="post"><input class="form-control mb-3" type="email" name="email" placeholder="Email address" required><input class="form-control mb-3" type="password" name="password" placeholder="Password" required><button class="btn btn-primary w-100" name="btnreg">Sign In</button></form><div class="text-center mt-3">New user? <a href="signup.php">Create account</a></div></div><script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/js/all.min.js"></script></body></html>
