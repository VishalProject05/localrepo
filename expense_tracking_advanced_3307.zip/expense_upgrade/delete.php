<?php require_once 'auth.php';
    $id = $_REQUEST['id'];
    $con = require_once "config.php"; $con=$conn;
    $qry = "delete from tblexpence where id = $id";
    mysqli_query($con, $qry);
    header("location:manageexpense.php");
?>