<?php
require_once "auth.php"; requireLogin(); if($_SESSION["role"]==="Admin"){header("Location:admin_dashboard.php");exit;}
$pageTitle="Member Dashboard"; $uid=$_SESSION["user_id"];
$my=$pdo->prepare("SELECT COUNT(*) FROM issue_returns WHERE member_id=? AND status='Issued'");$my->execute([$uid]);$myBooks=(int)$my->fetchColumn();
$due=$pdo->prepare("SELECT COUNT(*) FROM issue_returns WHERE member_id=? AND status='Issued' AND return_date<CURDATE()");$due->execute([$uid]);$dueBooks=(int)$due->fetchColumn();
$recent=$pdo->prepare("SELECT ir.*,b.title FROM issue_returns ir JOIN books b ON b.id=ir.book_id WHERE ir.member_id=? ORDER BY ir.id DESC LIMIT 5");$recent->execute([$uid]);$recent=$recent->fetchAll();
require "partials/header.php"; require "partials/sidebar.php"; ?>
<h5>Welcome, <?=e($_SESSION["full_name"])?>!</h5><p class="text-muted small"><?=e($_SESSION["role"])?> | Member ID: <?=e($_SESSION["member_code"])?></p>
<div class="row g-3"><div class="col-md-4"><div class="stat blue"><h6>📚 My Books</h6><h2><?=$myBooks?></h2></div></div><div class="col-md-4"><div class="stat green"><h6>👥 Issued Books</h6><h2><?=$myBooks?></h2></div></div><div class="col-md-4"><div class="stat" style="background:#ed3150"><h6>▣ Due Books</h6><h2><?=$dueBooks?></h2></div></div></div>
<div class="card p-3 mt-3"><h6>Recently Issued Books</h6><div class="table-responsive"><table class="table"><thead><tr><th>#</th><th>Book Name</th><th>Issue Date</th><th>Return Date</th><th>Status</th></tr></thead><tbody><?php foreach($recent as $i=>$r): ?><tr><td><?=$i+1?></td><td><?=e($r["title"])?></td><td><?=$r["issue_date"]?></td><td><?=$r["return_date"]?></td><td><span class="badge-soft"><?=$r["status"]?></span></td></tr><?php endforeach;?></tbody></table></div></div>
<?php require "partials/footer.php"; ?>