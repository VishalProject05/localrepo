<?php
require_once "auth.php";
if (isLoggedIn()) { header("Location: index.php"); exit; }
$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
    $stmt->execute([$email]);
    $u = $stmt->fetch();
    if ($u && password_verify($password, $u["password"])) {
        session_regenerate_id(true);
        $_SESSION["user_id"]=$u["id"]; $_SESSION["full_name"]=$u["full_name"];
        $_SESSION["role"]=$u["role"]; $_SESSION["member_code"]=$u["member_code"];
        header("Location: index.php"); exit;
    }
    $error="Invalid email or password.";
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login - Online Library</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link rel="stylesheet" href="assets/style.css"></head>
<body class="auth-bg"><div class="auth-box text-center">
<div style="font-size:48px">📖</div><h5>Welcome Back!</h5><p class="text-muted small">Login to your account</p>
<?php if($error): ?><div class="alert alert-danger py-2"><?=e($error)?></div><?php endif; ?>
<form method="post" class="text-start">
<label class="small">Email or Username</label><input class="form-control mb-3" type="email" name="email" required>
<label class="small">Password</label><input class="form-control mb-3" type="password" name="password" required>
<button class="btn btn-primary w-100">Login</button>
</form>
<p class="small mt-3">Don't have an account? <a href="register.php">Register here</a></p>
</div></body></html>