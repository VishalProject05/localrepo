<?php
require_once __DIR__ . "/config.php";

function isLoggedIn(): bool {
    return isset($_SESSION["user_id"]);
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit;
    }
}

function requireAdmin(): void {
    requireLogin();
    if ($_SESSION["role"] !== "Admin") {
        header("Location: member_dashboard.php");
        exit;
    }
}

function e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

function flash(string $key, ?string $value = null): ?string {
    if ($value !== null) {
        $_SESSION["flash"][$key] = $value;
        return null;
    }
    $msg = $_SESSION["flash"][$key] ?? null;
    unset($_SESSION["flash"][$key]);
    return $msg;
}
?>