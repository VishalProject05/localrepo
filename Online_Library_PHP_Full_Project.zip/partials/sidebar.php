<?php $current = basename($_SERVER["PHP_SELF"]); ?>
<aside class="sidebar">
<?php if ($_SESSION["role"] === "Admin"): ?>
  <a class="<?= $current==='admin_dashboard.php'?'active':'' ?>" href="admin_dashboard.php">🏠 <span>Dashboard</span></a>
  <a class="<?= in_array($current,['books.php','book_form.php','book_details.php'])?'active':'' ?>" href="books.php">📚 <span>Books</span></a>
  <a class="<?= $current==='members.php'?'active':'' ?>" href="members.php">👥 <span>Members</span></a>
  <a class="<?= $current==='issue_return.php'?'active':'' ?>" href="issue_return.php">▣ <span>Issue / Return</span></a>
  <a class="<?= $current==='search.php'?'active':'' ?>" href="search.php">⌕ <span>Search</span></a>
  <a class="<?= $current==='reports.php'?'active':'' ?>" href="reports.php">▤ <span>Reports</span></a>
  <a href="profile.php">⚙ <span>Settings</span></a>
<?php else: ?>
  <a class="<?= $current==='member_dashboard.php'?'active':'' ?>" href="member_dashboard.php">🏠 <span>Dashboard</span></a>
  <a class="<?= $current==='my_books.php'?'active':'' ?>" href="my_books.php">📚 <span>My Books</span></a>
  <a class="<?= $current==='issue_return.php'?'active':'' ?>" href="issue_return.php">▣ <span>Issue / Return</span></a>
  <a class="<?= $current==='search.php'?'active':'' ?>" href="search.php">⌕ <span>Search</span></a>
  <a class="<?= $current==='profile.php'?'active':'' ?>" href="profile.php">◉ <span>Profile</span></a>
<?php endif; ?>
  <a class="logout" href="logout.php">⇥ <span>Logout</span></a>
</aside>
<main class="content">