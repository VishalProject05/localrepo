<?php
require_once __DIR__ . "/../auth.php";
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($pageTitle ?? "Online Library") ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="topbar">
  <div><span class="brand-icon">📖</span><span class="brand">Online Library<small>Management System</small></span></div>
  <div class="links">
    <a class="navbar-link" href="<?= $_SESSION['role']==='Admin'?'admin_dashboard.php':'member_dashboard.php' ?>">Read</a>
    <a class="navbar-link" href="search.php">Learn</a>
    <a class="navbar-link" href="profile.php">Grow</a>
    <span class="ms-4">🔔 &nbsp; 👤 <?= e($_SESSION['full_name']) ?> ▾</span>
  </div>
</div>
<div class="layout">