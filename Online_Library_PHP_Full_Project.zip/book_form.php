<?php
require_once "auth.php"; requireAdmin();
$id=(int)($_GET["id"]??0);$book=$id?$pdo->query("SELECT * FROM books WHERE id=$id")->fetch():null;
if($_SERVER["REQUEST_METHOD"]==="POST"){
 $title=trim($_POST["title"]);$author=trim($_POST["author"]);$category=trim($_POST["category"]);$total=(int)$_POST["total_copies"];$available=(int)$_POST["available_copies"];$desc=trim($_POST["description"]);
 if($id){$st=$pdo->prepare("UPDATE books SET title=?,author=?,category=?,total_copies=?,available_copies=?,description=? WHERE id=?");$st->execute([$title,$author,$category,$total,$available,$desc,$id]);}
 else{$st=$pdo->prepare("INSERT INTO books(title,author,category,total_copies,available_copies,description) VALUES(?,?,?,?,?,?)");$st->execute([$title,$author,$category,$total,$available,$desc]);}
 header("Location:books.php");exit;
}
$pageTitle=$id?"Edit Book":"Add Book";require "partials/header.php";require "partials/sidebar.php"; ?>
<h5><?=$id?"Edit Book":"Add New Book"?></h5><div class="card p-4 mt-3">
<form method="post"><div class="row g-3"><div class="col-md-6"><label>Book Title</label><input class="form-control" name="title" required value="<?=e($book["title"]??"")?>"></div><div class="col-md-6"><label>Author</label><input class="form-control" name="author" required value="<?=e($book["author"]??"")?>"></div><div class="col-md-6"><label>Category</label><input class="form-control" name="category" required value="<?=e($book["category"]??"")?>"></div><div class="col-md-3"><label>Total Copies</label><input class="form-control" type="number" name="total_copies" min="1" required value="<?=e($book["total_copies"]??1)?>"></div><div class="col-md-3"><label>Available Copies</label><input class="form-control" type="number" name="available_copies" min="0" required value="<?=e($book["available_copies"]??1)?>"></div><div class="col-12"><label>Description</label><textarea class="form-control" name="description" rows="4"><?=e($book["description"]??"")?></textarea></div></div><button class="btn btn-primary mt-3">Save Book</button> <a href="books.php" class="btn btn-light mt-3">Cancel</a></form></div><?php require "partials/footer.php"; ?>