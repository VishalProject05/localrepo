<?php
require_once "config.php";
$hash = password_hash("admin123", PASSWORD_DEFAULT);
$studentHash = password_hash("123456", PASSWORD_DEFAULT);

$pdo->exec("UPDATE users SET password = " . $pdo->quote($hash) . " WHERE role='Admin'");
$pdo->exec("UPDATE users SET password = " . $pdo->quote($studentHash) . " WHERE role<>'Admin'");
echo "<h2>Setup complete</h2><p>Admin: admin@library.com / admin123</p><p>Student: rahul@gmail.com / 123456</p><p><b>Delete setup.php after running it.</b></p>";
?>