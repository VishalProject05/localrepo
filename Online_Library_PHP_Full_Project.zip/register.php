<?php
require_once "auth.php";
if (isLoggedIn()) { header("Location:index.php"); exit; }
$error="";
if($_SERVER["REQUEST_METHOD"]==="POST"){
 $name=trim($_POST["full_name"]);$email=trim($_POST["email"]);$mobile=trim($_POST["mobile"]);
 $password=$_POST["password"];$confirm=$_POST["confirm_password"];
 if($password!==$confirm){$error="Passwords do not match.";}
 else{
  $check=$pdo->prepare("SELECT id FROM users WHERE email=?");$check->execute([$email]);
  if($check->fetch()){$error="Email already registered.";}
  else{
   $code="M".str_pad((string)(($pdo->query("SELECT COUNT(*) FROM users WHERE role<>'Admin'")->fetchColumn())+1),3,"0",STR_PAD_LEFT);
   $stmt=$pdo->prepare("INSERT INTO users(full_name,email,mobile,password,role,member_code,created_at) VALUES(?,?,?,?,?,?,CURDATE())");
   $stmt->execute([$name,$email,$mobile,password_hash($password,PASSWORD_DEFAULT),"Student",$code]);
   flash("success","Registration successful. Please login."); header("Location:login.php"); exit;
  }
 }
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Registration - Online Library</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link rel="stylesheet" href="assets/style.css"></head>
<body class="auth-bg"><div class="auth-box">
<div class="text-center" style="font-size:40px">👤</div><h5 class="text-center">Create New Account</h5><p class="text-center text-muted small">Join our library system</p>
<?php if($error): ?><div class="alert alert-danger py-2"><?=$error?></div><?php endif; ?>
<form method="post">
<input class="form-control mb-2" name="full_name" placeholder="Full Name" required>
<input class="form-control mb-2" type="email" name="email" placeholder="Email" required>
<input class="form-control mb-2" name="mobile" placeholder="Mobile Number">
<select class="form-select mb-2" name="role" disabled><option>Student</option></select>
<input class="form-control mb-2" type="password" name="password" placeholder="Password" required minlength="6">
<input class="form-control mb-3" type="password" name="confirm_password" placeholder="Confirm Password" required>
<button class="btn btn-primary w-100">Register</button>
</form><p class="small text-center mt-3">Already have an account? <a href="login.php">Login</a></p>
</div></body></html>