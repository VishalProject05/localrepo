# Online Library Management System - PHP + MySQL

## Requirements
- XAMPP / WAMP / Laragon
- PHP 8+
- MySQL / MariaDB
- Browser

## Installation
1. Copy the `online_library_php` folder into `htdocs` (XAMPP) or your web root.
2. Start Apache and MySQL.
3. Open phpMyAdmin and import `database.sql`.
4. Open `http://localhost/online_library_php/setup.php`.
5. Login:
   - Admin: `admin@library.com` / `admin123`
   - Student: `rahul@gmail.com` / `123456`
6. Delete `setup.php` after setup.

## Database configuration
Edit `config.php` if your MySQL username/password is different.

## Main pages
- Login / Registration
- Admin Dashboard
- Member Dashboard
- Books Management
- Members Management
- Issue / Return
- Search Books
- Book Details
- My Books
- Profile
- Reports

This is a starter academic project. For production use, add CSRF protection, stricter validation, audit logs, pagination and environment-based secrets.
