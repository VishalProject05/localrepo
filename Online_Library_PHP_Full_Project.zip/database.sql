CREATE DATABASE IF NOT EXISTS online_library CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE online_library;

DROP TABLE IF EXISTS issue_returns;
DROP TABLE IF EXISTS books;
DROP TABLE IF EXISTS members;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    mobile VARCHAR(20) DEFAULT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('Admin','Student','Staff') NOT NULL DEFAULT 'Student',
    member_code VARCHAR(30) UNIQUE,
    created_at DATE NOT NULL
);

CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    author VARCHAR(120) NOT NULL,
    category VARCHAR(80) NOT NULL,
    total_copies INT NOT NULL DEFAULT 1,
    available_copies INT NOT NULL DEFAULT 1,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE issue_returns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT NOT NULL,
    book_id INT NOT NULL,
    issue_date DATE NOT NULL,
    return_date DATE NOT NULL,
    actual_return_date DATE DEFAULT NULL,
    status ENUM('Issued','Returned','Overdue') NOT NULL DEFAULT 'Issued',
    FOREIGN KEY (member_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
);

INSERT INTO users (full_name,email,mobile,password,role,member_code,created_at) VALUES
('Admin','admin@library.com','9000000000', '$2y$10$92IXUNZ8QyK6XQ9b5k0V8O7ZgQ6u5b1m0mM6Q6k0H9Z8m5e7x8p9S', 'Admin','ADM001','2026-09-01'),
('Rahul Kumar','rahul@gmail.com','9876543210', '$2y$10$92IXUNZ8QyK6XQ9b5k0V8O7ZgQ6u5b1m0mM6Q6k0H9Z8m5e7x8p9S', 'Student','M001','2025-06-01'),
('Priya Singh','priya@gmail.com','8765422109', '$2y$10$92IXUNZ8QyK6XQ9b5k0V8O7ZgQ6u5b1m0mM6Q6k0H9Z8m5e7x8p9S', 'Student','M002','2025-06-02'),
('Amit Yadav','amit@gmail.com','7654321098', '$2y$10$92IXUNZ8QyK6XQ9b5k0V8O7ZgQ6u5b1m0mM6Q6k0H9Z8m5e7x8p9S', 'Student','M003','2025-06-03'),
('Sneha Gupta','sneha@gmail.com','6543210987', '$2y$10$92IXUNZ8QyK6XQ9b5k0V8O7ZgQ6u5b1m0mM6Q6k0H9Z8m5e7x8p9S', 'Student','M004','2025-06-04'),
('Rohan Sharma','rohan@gmail.com','5432108765', '$2y$10$92IXUNZ8QyK6XQ9b5k0V8O7ZgQ6u5b1m0mM6Q6k0H9Z8m5e7x8p9S', 'Student','M005','2025-06-05');

INSERT INTO books (title,author,category,total_copies,available_copies,description) VALUES
('C Programming','Dennis Ritchie','Programming',10,8,'A classic introduction to C programming and computer programming fundamentals.'),
('Python Basics','Guido van Rossum','Programming',15,12,'Beginner friendly Python programming concepts and examples.'),
('Data Structures','R. G. Dromey','Computer Science',10,7,'Core data structures, algorithms and problem solving.'),
('Java Programming','Herbert Schildt','Programming',12,10,'Java programming concepts from fundamentals to advanced topics.'),
('Web Development','Jon Duckett','Web',8,6,'HTML, CSS and JavaScript concepts for modern web development.');

INSERT INTO issue_returns (member_id,book_id,issue_date,return_date,status) VALUES
(2,1,'2025-09-01','2025-09-15','Issued'),
(3,3,'2025-09-02','2025-09-16','Issued'),
(4,2,'2025-09-03','2025-09-17','Issued'),
(5,4,'2025-09-04','2025-09-18','Issued'),
(6,5,'2025-09-05','2025-09-19','Issued');
